-- Create blockchain audit log table for immutable transaction tracking
CREATE TABLE IF NOT EXISTS blockchain_audit_log (
  id VARCHAR(36) PRIMARY KEY,
  action_type ENUM(
    'RECORD_CREATED',
    'RECORD_DELETED',
    'DOWNLOAD_REQUESTED',
    'DOWNLOAD_APPROVED',
    'DOWNLOAD_REJECTED',
    'DOWNLOAD_COMPLETED',
    'STATUS_CHANGED'
  ) NOT NULL,
  record_id VARCHAR(36),
  request_id VARCHAR(36),
  user_id VARCHAR(36) NOT NULL,
  user_name VARCHAR(255) NOT NULL,
  user_role ENUM('doctor', 'patient', 'admin') NOT NULL,
  actor_user_id VARCHAR(36),
  actor_user_name VARCHAR(255),
  actor_user_role ENUM('doctor', 'patient', 'admin'),
  patient_id VARCHAR(36),
  description TEXT,
  details JSON,
  blockchain_tx VARCHAR(255),
  blockchain_block_number INT,
  timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  immutable BOOLEAN DEFAULT TRUE,
  
  INDEX idx_record_id (record_id),
  INDEX idx_request_id (request_id),
  INDEX idx_user_id (user_id),
  INDEX idx_action_type (action_type),
  INDEX idx_timestamp (timestamp),
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (actor_user_id) REFERENCES users(id),
  FOREIGN KEY (patient_id) REFERENCES users(id),
  FOREIGN KEY (record_id) REFERENCES medical_records(id) ON DELETE SET NULL,
  FOREIGN KEY (request_id) REFERENCES download_requests(id) ON DELETE SET NULL
);

-- Create index on blockchain_tx for quick lookups
CREATE INDEX idx_blockchain_tx ON blockchain_audit_log(blockchain_tx);

-- Create index on immutable records for faster queries
CREATE INDEX idx_immutable_records ON blockchain_audit_log(immutable, timestamp);
