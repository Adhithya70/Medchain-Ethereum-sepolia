-- Add blockchain_tx column to medical_records table
ALTER TABLE medical_records ADD COLUMN blockchain_tx VARCHAR(255) NULL;

-- Add blockchain_tx column to download_requests table
ALTER TABLE download_requests ADD COLUMN blockchain_tx VARCHAR(255) NULL;

-- Add blockchain_tx column to download_history table
ALTER TABLE download_history ADD COLUMN blockchain_tx VARCHAR(255) NULL;
