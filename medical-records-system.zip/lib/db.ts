import mysql from "mysql2/promise"
import crypto from "crypto"

// Database connection pool
const pool = mysql.createPool({
  host: "localhost",
  user: "root",
  password: "Adhi@2002",
  database: "medical_record",
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
})

// Generate a unique ID
export function generateId(): string {
  return crypto.randomUUID()
}

// Generate SHA-256 hash for a record
export function generateHash(data: string): string {
  return crypto.createHash("sha256").update(data).digest("hex")
}

// User authentication
export async function authenticateUser(userId: string, password: string, role: string) {
  try {
    const [rows]: any = await pool.query("SELECT * FROM users WHERE id = ? AND password = ? AND role = ?", [
      userId,
      password,
      role,
    ])

    return rows.length > 0 ? rows[0] : null
  } catch (error) {
    console.error("Authentication error:", error)
    return null
  }
}

// Get user by ID
export async function getUserById(userId: string) {
  try {
    const [rows]: any = await pool.query("SELECT * FROM users WHERE id = ?", [userId])
    return rows.length > 0 ? rows[0] : null
  } catch (error) {
    console.error("Get user error:", error)
    return null
  }
}

// Get all doctors
export async function getAllDoctors() {
  try {
    const [rows]: any = await pool.query("SELECT * FROM users WHERE role = ?", ["doctor"])
    return rows
  } catch (error) {
    console.error("Get doctors error:", error)
    return []
  }
}

// Get all patients
export async function getAllPatients() {
  try {
    const [rows]: any = await pool.query("SELECT * FROM users WHERE role = ?", ["patient"])
    return rows
  } catch (error) {
    console.error("Get patients error:", error)
    return []
  }
}

// Create a new user
export async function createUser(userData: any) {
  try {
    const userId = userData.id || generateId()
    const result = await pool.query(
      "INSERT INTO users (id, name, password, role, specialization, university, graduation_year, experience, college, joining_date, age, sex, blood_group, remarks) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
      [
        userId,
        userData.name,
        userData.password,
        userData.role,
        userData.specialization || null,
        userData.university || null,
        userData.graduation_year || null,
        userData.experience || null,
        userData.college || null,
        userData.joining_date || new Date(),
        userData.age || null,
        userData.sex || null,
        userData.blood_group || null,
        userData.remarks || null,
      ],
    )
    return { ...userData, id: userId }
  } catch (error) {
    console.error("Create user error:", error)
    return null
  }
}

// Update a user
export async function updateUser(userId: string, userData: any) {
  try {
    await pool.query(
      "UPDATE users SET name = ?, specialization = ?, university = ?, graduation_year = ?, experience = ?, college = ?, age = ?, sex = ?, blood_group = ?, remarks = ? WHERE id = ?",
      [
        userData.name,
        userData.specialization || null,
        userData.university || null,
        userData.graduation_year || null,
        userData.experience || null,
        userData.college || null,
        userData.age || null,
        userData.sex || null,
        userData.blood_group || null,
        userData.remarks || null,
        userId,
      ],
    )
    return { ...userData, id: userId }
  } catch (error) {
    console.error("Update user error:", error)
    return null
  }
}

// Delete a user
export async function deleteUser(userId: string) {
  try {
    await pool.query("DELETE FROM users WHERE id = ?", [userId])
    return true
  } catch (error) {
    console.error("Delete user error:", error)
    return false
  }
}

// Get medical records for a patient
export async function getPatientRecords(patientId: string) {
  try {
    const [rows]: any = await pool.query(
      "SELECT r.*, u.name as creator_name FROM medical_records r JOIN users u ON r.created_by = u.id WHERE r.patient_id = ?",
      [patientId],
    )
    return rows
  } catch (error) {
    console.error("Get patient records error:", error)
    return []
  }
}

// Get a specific medical record
export async function getMedicalRecord(recordId: string) {
  try {
    const [rows]: any = await pool.query("SELECT * FROM medical_records WHERE id = ?", [recordId])
    return rows.length > 0 ? rows[0] : null
  } catch (error) {
    console.error("Get medical record error:", error)
    return null
  }
}

// Create a medical record
export async function createMedicalRecord(recordData: any) {
  try {
    const recordId = generateId()
    const hash = generateHash(JSON.stringify(recordData))

    await pool.query(
      "INSERT INTO medical_records (id, patient_id, description, file_name, file_type, file_size, file_path, file_data, hash, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
      [
        recordId,
        recordData.patient_id,
        recordData.description,
        recordData.file_name,
        recordData.file_type,
        recordData.file_size,
        recordData.file_path,
        recordData.file_data,
        hash,
        recordData.created_by,
      ],
    )

    return { ...recordData, id: recordId, hash }
  } catch (error) {
    console.error("Create medical record error:", error)
    return null
  }
}

// Delete a medical record
export async function deleteMedicalRecord(recordId: string) {
  try {
    await pool.query("DELETE FROM medical_records WHERE id = ?", [recordId])
    return true
  } catch (error) {
    console.error("Delete medical record error:", error)
    return false
  }
}

// Create a download request
export async function createDownloadRequest(requestData: any) {
  try {
    const requestId = generateId()

    await pool.query(
      "INSERT INTO download_requests (id, patient_id, record_id, record_hash, record_description, status) VALUES (?, ?, ?, ?, ?, ?)",
      [
        requestId,
        requestData.patient_id,
        requestData.record_id,
        requestData.record_hash,
        requestData.record_description,
        "pending",
      ],
    )

    return { ...requestData, id: requestId, status: "pending" }
  } catch (error) {
    console.error("Create download request error:", error)
    return null
  }
}

// Get download requests for a patient
export async function getPatientRequests(patientId: string) {
  try {
    const [rows]: any = await pool.query(
      "SELECT * FROM download_requests WHERE patient_id = ? ORDER BY requested_at DESC",
      [patientId],
    )
    return rows
  } catch (error) {
    console.error("Get patient requests error:", error)
    return []
  }
}

// Get all pending download requests
export async function getPendingRequests() {
  try {
    const [rows]: any = await pool.query(
      `SELECT r.*, u.name as patient_name 
       FROM download_requests r 
       JOIN users u ON r.patient_id = u.id 
       WHERE r.status = 'pending' 
       ORDER BY r.requested_at ASC`,
    )
    return rows
  } catch (error) {
    console.error("Get pending requests error:", error)
    return []
  }
}

// Update download request status
export async function updateRequestStatus(requestId: string, status: string) {
  try {
    const now = new Date()
    let updateFields = ""
    const params = [status]

    if (status === "approved") {
      updateFields = ", approved_at = ?"
      params.push(now)
    } else if (status === "rejected") {
      updateFields = ", rejected_at = ?"
      params.push(now)
    } else if (status === "downloaded") {
      updateFields = ", downloaded_at = ?"
      params.push(now)
    }

    params.push(requestId)

    await pool.query(`UPDATE download_requests SET status = ?${updateFields} WHERE id = ?`, params)

    // If approved, get the request details to add to download history
    if (status === "downloaded") {
      const [rows]: any = await pool.query("SELECT * FROM download_requests WHERE id = ?", [requestId])
      if (rows.length > 0) {
        const request = rows[0]
        await pool.query(
          "INSERT INTO download_history (id, patient_id, record_id, record_hash, record_description) VALUES (?, ?, ?, ?, ?)",
          [generateId(), request.patient_id, request.record_id, request.record_hash, request.record_description],
        )
      }
    }

    return true
  } catch (error) {
    console.error("Update request status error:", error)
    return false
  }
}

// Add this function to get a specific download request by ID
export async function getRequestById(requestId: string) {
  try {
    const [rows]: any = await pool.query("SELECT * FROM download_requests WHERE id = ?", [requestId])
    return rows.length > 0 ? rows[0] : null
  } catch (error) {
    console.error("Get request error:", error)
    return null
  }
}

// Add a function to update blockchain transaction hash for a record
export async function updateRecordBlockchainTx(recordId: string, blockchainTx: string) {
  try {
    await pool.query("UPDATE medical_records SET blockchain_tx = ? WHERE id = ?", [blockchainTx, recordId])
    return true
  } catch (error) {
    console.error("Update record blockchain tx error:", error)
    return false
  }
}

// Add a function to update blockchain transaction hash for a request
export async function updateRequestBlockchainTx(requestId: string, blockchainTx: string) {
  try {
    await pool.query("UPDATE download_requests SET blockchain_tx = ? WHERE id = ?", [blockchainTx, requestId])
    return true
  } catch (error) {
    console.error("Update request blockchain tx error:", error)
    return false
  }
}

// Add this function to get all medical records with patient and creator names
export async function getAllMedicalRecords() {
  try {
    const [rows]: any = await pool.query(
      `SELECT mr.*, p.name as patient_name, c.name as creator_name 
       FROM medical_records mr
       JOIN users p ON mr.patient_id = p.id
       JOIN users c ON mr.created_by = c.id
       ORDER BY mr.created_at DESC`,
    )
    return rows
  } catch (error) {
    console.error("Get all medical records error:", error)
    return []
  }
}

// Add this function to get all medical records created by a specific user
export async function getAllMedicalRecordsByCreator(creatorId: string) {
  try {
    const [rows]: any = await pool.query(
      `SELECT mr.*, p.name as patient_name
       FROM medical_records mr
       JOIN users p ON mr.patient_id = p.id
       WHERE mr.created_by = ?
       ORDER BY mr.created_at DESC`,
      [creatorId],
    )
    return rows
  } catch (error) {
    console.error("Get medical records by creator error:", error)
    return []
  }
}

export type User = {
  id: string
  name: string
  username?: string
  role: string
}

export default pool
