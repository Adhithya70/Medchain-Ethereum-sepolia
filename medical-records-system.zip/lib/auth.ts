import { cookies } from "next/headers"
import { redirect } from "next/navigation"
import { getUserById } from "./db"

// Set user session
export async function setUserSession(user: any) {
  const cookieStore = await cookies()
  const sessionData = {
    id: user.id,
    name: user.name,
    role: user.role,
  }

  cookieStore.set("user_session", JSON.stringify(sessionData), {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    maxAge: 60 * 60 * 24, // 1 day
    path: "/",
  })
}

// Get current user session
export async function getUserSession() {
  const cookieStore = await cookies()
  const sessionCookie = cookieStore.get("user_session")

  if (!sessionCookie) {
    return null
  }

  try {
    const sessionData = JSON.parse(sessionCookie.value)
    const user = await getUserById(sessionData.id)

    if (!user) {
      return null
    }

    return {
      id: user.id,
      name: user.name,
      role: user.role,
    }
  } catch (error) {
    console.error("Session parsing error:", error)
    return null
  }
}

// Clear user session
export async function clearUserSession() {
  const cookieStore = await cookies()
  cookieStore.delete("user_session")
}

// Auth middleware
export async function requireAuth(allowedRoles: string[] = []) {
  const user = await getUserSession()

  if (!user) {
    redirect("/")
  }

  if (allowedRoles.length > 0 && !allowedRoles.includes(user.role)) {
    redirect(`/dashboard/${user.role}`)
  }

  return user
}
