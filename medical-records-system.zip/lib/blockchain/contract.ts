import { ethers } from "ethers"
import RecordTrackerABI from "./RecordTracker.json"

// Contract configuration
export const CONTRACT_ADDRESS = process.env.CONTRACT_ADDRESS || "0xb615F50557617845A9cd77cAf1C3652Afa2302fa"
const WALLET_PRIVATE_KEY =
  process.env.WALLET_PRIVATE_KEY || "e9ffa8ef0c22bb328721a61fdfbabc75f189f733aee8555f4c391c60face0d69"
const SEPOLIA_RPC_URL =
  process.env.SEPOLIA_RPC_URL || "https://eth-sepolia.g.alchemy.com/v2/Tvu5loxzfMI5jmkiLsHwEfBqYp4al_uj"

// Initialize provider and signer
let provider: ethers.JsonRpcProvider | ethers.BrowserProvider
let signer: ethers.Wallet | ethers.JsonRpcSigner
let contract: ethers.Contract

// Initialize the blockchain connection
export async function initBlockchain(externalProvider?: any) {
  try {
    // Check if we're in a browser environment and if a provider was passed
    if (typeof window !== "undefined" && externalProvider) {
      console.log("Using external provider for blockchain connection")
      // Use connected wallet if available
      provider = new ethers.BrowserProvider(externalProvider)
      signer = await provider.getSigner()
    } else {
      console.log("Using default wallet for blockchain connection")
      // Fall back to default wallet
      provider = new ethers.JsonRpcProvider(SEPOLIA_RPC_URL)
      signer = new ethers.Wallet(WALLET_PRIVATE_KEY, provider)
    }

    // Create contract instance
    contract = new ethers.Contract(CONTRACT_ADDRESS, RecordTrackerABI.abi, signer)

    console.log("Blockchain connection initialized successfully")
    return true
  } catch (error) {
    console.error("Failed to initialize blockchain connection:", error)

    // Always initialize with default wallet if there's an error
    try {
      console.log("Falling back to default wallet")
      provider = new ethers.JsonRpcProvider(SEPOLIA_RPC_URL)
      signer = new ethers.Wallet(WALLET_PRIVATE_KEY, provider)
      contract = new ethers.Contract(CONTRACT_ADDRESS, RecordTrackerABI.abi, signer)
      console.log("Fallback blockchain connection initialized successfully")
      return true
    } catch (fallbackError) {
      console.error("Failed to initialize fallback blockchain connection:", fallbackError)
      return false
    }
  }
}

// Record functions
export async function logRecordAdded(
  recordId: string,
  recordHash: string,
  patientId: string,
  createdBy: string,
  externalProvider?: any,
) {
  try {
    // Initialize with the external provider if provided
    await initBlockchain(externalProvider)

    const tx = await contract.logRecordAdded(recordId, recordHash, patientId, createdBy)
    const receipt = await tx.wait()

    console.log(`Record added transaction logged: ${tx.hash}`)
    return { success: true, txHash: tx.hash }
  } catch (error) {
    console.error("Failed to log record added:", error)

    // Try again with the default wallet if using external provider failed
    if (externalProvider) {
      console.log("Retrying with default wallet...")
      try {
        await initBlockchain(undefined)
        const tx = await contract.logRecordAdded(recordId, recordHash, patientId, createdBy)
        const receipt = await tx.wait()
        console.log(`Record added transaction logged with default wallet: ${tx.hash}`)
        return { success: true, txHash: tx.hash }
      } catch (retryError) {
        console.error("Failed to log record added with default wallet:", retryError)
      }
    }

    return { success: false, error: error }
  }
}

export async function logRecordApproved(recordId: string, recordHash: string, externalProvider?: any) {
  try {
    await initBlockchain(externalProvider)

    const tx = await contract.logRecordApproved(recordId, recordHash)
    const receipt = await tx.wait()

    console.log(`Record approved transaction logged: ${tx.hash}`)
    return { success: true, txHash: tx.hash }
  } catch (error) {
    console.error("Failed to log record approved:", error)

    // Try again with the default wallet if using external provider failed
    if (externalProvider) {
      try {
        await initBlockchain(undefined)
        const tx = await contract.logRecordApproved(recordId, recordHash)
        const receipt = await tx.wait()
        console.log(`Record approved transaction logged with default wallet: ${tx.hash}`)
        return { success: true, txHash: tx.hash }
      } catch (retryError) {
        console.error("Failed to log record approved with default wallet:", retryError)
      }
    }

    return { success: false, error: error }
  }
}

export async function logRecordDeleted(recordId: string, externalProvider?: any) {
  try {
    await initBlockchain(externalProvider)

    const tx = await contract.logRecordDeleted(recordId)
    const receipt = await tx.wait()

    console.log(`Record deleted transaction logged: ${tx.hash}`)
    return { success: true, txHash: tx.hash }
  } catch (error) {
    console.error("Failed to log record deleted:", error)

    // Try again with the default wallet if using external provider failed
    if (externalProvider) {
      try {
        await initBlockchain(undefined)
        const tx = await contract.logRecordDeleted(recordId)
        const receipt = await tx.wait()
        console.log(`Record deleted transaction logged with default wallet: ${tx.hash}`)
        return { success: true, txHash: tx.hash }
      } catch (retryError) {
        console.error("Failed to log record deleted with default wallet:", retryError)
      }
    }

    return { success: false, error: error }
  }
}

export async function logRecordModified(recordId: string, externalProvider?: any) {
  try {
    await initBlockchain(externalProvider)

    const tx = await contract.logRecordModified(recordId)
    const receipt = await tx.wait()

    console.log(`Record modified transaction logged: ${tx.hash}`)
    return { success: true, txHash: tx.hash }
  } catch (error) {
    console.error("Failed to log record modified:", error)

    // Try again with the default wallet if using external provider failed
    if (externalProvider) {
      try {
        await initBlockchain(undefined)
        const tx = await contract.logRecordModified(recordId)
        const receipt = await tx.wait()
        console.log(`Record modified transaction logged with default wallet: ${tx.hash}`)
        return { success: true, txHash: tx.hash }
      } catch (retryError) {
        console.error("Failed to log record modified with default wallet:", retryError)
      }
    }

    return { success: false, error: error }
  }
}

// Request functions
export async function logRequestSubmitted(
  requestId: string,
  recordHash: string,
  patientId: string,
  externalProvider?: any,
) {
  try {
    await initBlockchain(externalProvider)

    const tx = await contract.logRequestSubmitted(requestId, recordHash, patientId)
    const receipt = await tx.wait()

    console.log(`Request submitted transaction logged: ${tx.hash}`)
    return { success: true, txHash: tx.hash }
  } catch (error) {
    console.error("Failed to log request submitted:", error)

    // Try again with the default wallet if using external provider failed
    if (externalProvider) {
      try {
        await initBlockchain(undefined)
        const tx = await contract.logRequestSubmitted(requestId, recordHash, patientId)
        const receipt = await tx.wait()
        console.log(`Request submitted transaction logged with default wallet: ${tx.hash}`)
        return { success: true, txHash: tx.hash }
      } catch (retryError) {
        console.error("Failed to log request submitted with default wallet:", retryError)
      }
    }

    return { success: false, error: error }
  }
}

export async function logRequestApproved(requestId: string, externalProvider?: any) {
  try {
    await initBlockchain(externalProvider)

    const tx = await contract.logRequestApproved(requestId)
    const receipt = await tx.wait()

    console.log(`Request approved transaction logged: ${tx.hash}`)
    return { success: true, txHash: tx.hash }
  } catch (error) {
    console.error("Failed to log request approved:", error)

    // Try again with the default wallet if using external provider failed
    if (externalProvider) {
      try {
        await initBlockchain(undefined)
        const tx = await contract.logRequestApproved(requestId)
        const receipt = await tx.wait()
        console.log(`Request approved transaction logged with default wallet: ${tx.hash}`)
        return { success: true, txHash: tx.hash }
      } catch (retryError) {
        console.error("Failed to log request approved with default wallet:", retryError)
      }
    }

    return { success: false, error: error }
  }
}

export async function logRequestRejected(requestId: string, externalProvider?: any) {
  try {
    await initBlockchain(externalProvider)

    const tx = await contract.logRequestRejected(requestId)
    const receipt = await tx.wait()

    console.log(`Request rejected transaction logged: ${tx.hash}`)
    return { success: true, txHash: tx.hash }
  } catch (error) {
    console.error("Failed to log request rejected:", error)

    // Try again with the default wallet if using external provider failed
    if (externalProvider) {
      try {
        await initBlockchain(undefined)
        const tx = await contract.logRequestRejected(requestId)
        const receipt = await tx.wait()
        console.log(`Request rejected transaction logged with default wallet: ${tx.hash}`)
        return { success: true, txHash: tx.hash }
      } catch (retryError) {
        console.error("Failed to log request rejected with default wallet:", retryError)
      }
    }

    return { success: false, error: error }
  }
}
