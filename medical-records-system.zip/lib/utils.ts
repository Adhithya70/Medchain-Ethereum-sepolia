export function formatDate(date: Date | string): string {
  return new Date(date).toLocaleDateString()
}

export function cn(...inputs: any[]): string {
  return inputs.filter(Boolean).join(" ")
}
