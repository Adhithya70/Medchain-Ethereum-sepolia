import { pool } from "./db/db"
import { v4 as uuidv4 } from "uuid"

export type AuditActionType =
  | "RECORD_CREATED"
  | "RECORD_DELETED"
  | "DOWNLOAD_REQUESTED"
  | "DOWNLOAD_APPROVED"
  | "DOWNLOAD_REJECTED"
  | "DOWNLOAD_COMPLETED"
  | "STATUS_CHANGED"

export interface AuditLogEntry {
  id: string
  action_type: AuditActionType
  record_id?: string
  request_id?: string
  user_id: string
  user_name: string
  user_role: "doctor" | "patient" | "admin"
  actor_user_id?: string
  actor_user_name?: string
  actor_user_role?: "doctor" | "patient" | "admin"
  patient_id?: string
  description?: string
  details?: Record<string, any>
  blockchain_tx?: string
  blockchain_block_number?: number
  timestamp?: string
}

export async function logAuditEvent(entry: Omit<AuditLogEntry, "id" | "timestamp">): Promise<string> {
  try {
    const id = uuidv4()

    const query = `
      INSERT INTO blockchain_audit_log (
        id,
        action_type,
        record_id,
        request_id,
        user_id,
        user_name,
        user_role,
        actor_user_id,
        actor_user_name,
        actor_user_role,
        patient_id,
        description,
        details,
        blockchain_tx,
        blockchain_block_number,
        immutable
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `

    const values = [
      id,
      entry.action_type,
      entry.record_id || null,
      entry.request_id || null,
      entry.user_id,
      entry.user_name,
      entry.user_role,
      entry.actor_user_id || null,
      entry.actor_user_name || null,
      entry.actor_user_role || null,
      entry.patient_id || null,
      entry.description || null,
      entry.details ? JSON.stringify(entry.details) : null,
      entry.blockchain_tx || null,
      entry.blockchain_block_number || null,
      true, // immutable by default
    ]

    await pool.query(query, values)

    return id
  } catch (error) {
    console.error("Error logging audit event:", error)
    throw error
  }
}

export async function getAuditLogs(
  filters?: {
    action_type?: AuditActionType
    record_id?: string
    request_id?: string
    user_id?: string
    patient_id?: string
    start_date?: string
    end_date?: string
    limit?: number
    offset?: number
  },
): Promise<AuditLogEntry[]> {
  try {
    let query = "SELECT * FROM blockchain_audit_log WHERE 1=1"
    const values: any[] = []

    if (filters?.action_type) {
      query += " AND action_type = ?"
      values.push(filters.action_type)
    }

    if (filters?.record_id) {
      query += " AND record_id = ?"
      values.push(filters.record_id)
    }

    if (filters?.request_id) {
      query += " AND request_id = ?"
      values.push(filters.request_id)
    }

    if (filters?.user_id) {
      query += " AND (user_id = ? OR actor_user_id = ?)"
      values.push(filters.user_id, filters.user_id)
    }

    if (filters?.patient_id) {
      query += " AND patient_id = ?"
      values.push(filters.patient_id)
    }

    if (filters?.start_date) {
      query += " AND timestamp >= ?"
      values.push(filters.start_date)
    }

    if (filters?.end_date) {
      query += " AND timestamp <= ?"
      values.push(filters.end_date)
    }

    query += " ORDER BY timestamp DESC"

    if (filters?.limit) {
      query += " LIMIT ?"
      values.push(filters.limit)

      if (filters?.offset) {
        query += " OFFSET ?"
        values.push(filters.offset)
      }
    }

    const [rows]: any = await pool.query(query, values)

    return (rows as any[]).map((row) => ({
      ...row,
      details: row.details 
        ? typeof row.details === 'string' 
          ? JSON.parse(row.details) 
          : row.details
        : undefined,
    }))
  } catch (error) {
    console.error("Error fetching audit logs:", error)
    return []
  }
}

export async function getRecordAuditTrail(recordId: string): Promise<AuditLogEntry[]> {
  return getAuditLogs({
    record_id: recordId,
    limit: 1000,
  })
}

export async function getPatientAuditTrail(patientId: string): Promise<AuditLogEntry[]> {
  return getAuditLogs({
    patient_id: patientId,
    limit: 1000,
  })
}

export async function getUserActivityLog(userId: string): Promise<AuditLogEntry[]> {
  return getAuditLogs({
    user_id: userId,
    limit: 500,
  })
}

export async function getAuditLogById(auditId: string): Promise<AuditLogEntry | null> {
  try {
    const query = "SELECT * FROM blockchain_audit_log WHERE id = ?"
    const [rows]: any = await pool.query(query, [auditId])

    const row = (rows as any[])[0]
    if (!row) return null

    return {
      ...row,
      details: row.details 
        ? typeof row.details === 'string' 
          ? JSON.parse(row.details) 
          : row.details
        : undefined,
    }
  } catch (error) {
    console.error("Error fetching audit log:", error)
    return null
  }
}
