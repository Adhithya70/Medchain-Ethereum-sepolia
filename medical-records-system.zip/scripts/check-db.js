const mysql = require('mysql2/promise');

async function checkDatabase() {
  console.log('\n🔍 Checking Database Connection...\n');

  const dbHost = process.env.DB_HOST || 'localhost';
  const dbUser = process.env.DB_USER || 'root';
  const dbPassword = process.env.DB_PASSWORD || 'Adhi@2002';
  const dbName = process.env.DB_NAME || 'medical_record';

  try {
    const connection = await mysql.createConnection({
      host: dbHost,
      user: dbUser,
      password: dbPassword,
      database: dbName,
    });

    // Test connection
    const [rows] = await connection.execute('SELECT 1');
    
    if (rows) {
      console.log('✅ Database Connection Status: CONNECTED\n');
      console.log(`   Host: ${dbHost}`);
      console.log(`   Database: ${dbName}`);
      console.log(`   User: ${dbUser}`);
      console.log('\n✨ Ready to start development server!\n');
    }

    await connection.end();
    process.exit(0);
  } catch (error) {
    console.error('\n❌ Database Connection Failed!\n');
    
    // Provide helpful error messages
    if (error.code === 'ECONNREFUSED') {
      console.error(`Error: MySQL server is not running at ${dbHost}:3306\n`);
      console.error('📋 To fix this, you need to:\n');
      console.error('   1. Start your MySQL server:');
      console.error('      • On Mac (Homebrew):   brew services start mysql');
      console.error('      • On Linux (Ubuntu):   sudo service mysql start');
      console.error('      • On Windows:          Search "Services" and start MySQL80');
      console.error('      • Using Docker:        docker run -d -p 3306:3306 -e MYSQL_ROOT_PASSWORD=Adhi@2002 -e MYSQL_DATABASE=medical_record mysql:latest\n');
    } else if (error.code === 'ER_ACCESS_DENIED_USER') {
      console.error('Error: Access denied - check your MySQL credentials\n');
    } else if (error.code === 'ER_BAD_DB_ERROR') {
      console.error(`Error: Database "${dbName}" does not exist\n`);
      console.error('📋 Create the database with:\n');
      console.error(`   mysql -u ${dbUser} -p -e "CREATE DATABASE ${dbName};"\n`);
    } else {
      console.error(`   Error: ${error.message}\n`);
    }

    console.error('📝 Configuration Used:');
    console.error(`   Host: ${dbHost}`);
    console.error(`   User: ${dbUser}`);
    console.error(`   Database: ${dbName}`);
    console.error('\n💡 You can override these in .env.local:\n');
    console.error('   DB_HOST=localhost');
    console.error('   DB_USER=root');
    console.error('   DB_PASSWORD=Adhi@2002');
    console.error('   DB_NAME=medical_record\n');
    
    // Continue development even if DB is not available
    console.log('⚠️  Continuing with development server anyway...\n');
    process.exit(0);
  }
}

checkDatabase();
