import { type NextRequest, NextResponse } from "next/server"
import { updateUser } from "@/lib/db"
import { requireAuth } from "@/lib/auth"

export async function PUT(request: NextRequest) {
  try {
    // Check if user is admin
    const user = await requireAuth(["admin"])

    const userData = await request.json()

    // Update admin's own profile
    const updatedAdmin = await updateUser(user.id, userData)

    if (!updatedAdmin) {
      return NextResponse.json({ message: "Failed to update profile" }, { status: 500 })
    }

    return NextResponse.json({
      message: "Profile updated successfully",
      admin: {
        id: updatedAdmin.id,
        name: updatedAdmin.name,
      },
    })
  } catch (error) {
    console.error("Update profile error:", error)
    return NextResponse.json({ message: "An error occurred while updating your profile" }, { status: 500 })
  }
}
