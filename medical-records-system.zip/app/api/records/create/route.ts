import { type NextRequest, NextResponse } from "next/server"
import { createMedicalRecord, updateRecordBlockchainTx, getUserById } from "@/lib/db"
import { requireAuth } from "@/lib/auth"
import { logAuditEvent } from "@/lib/audit-log"
import fs from "fs"
import path from "path"
import { v4 as uuidv4 } from "uuid"
import { logRecordAdded } from "@/lib/blockchain/contract"

// Create uploads directory if it doesn't exist
const uploadsDir = path.join(process.cwd(), "uploads")
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true })
}

export async function POST(request: NextRequest) {
  try {
    // Check if user is authorized
    const user = await requireAuth(["admin", "doctor"])

    const formData = await request.formData()

    const patientId = formData.get("patient_id") as string
    const description = formData.get("description") as string
    const createdBy = formData.get("created_by") as string
    const file = formData.get("file") as File

    // We can't use the browser wallet from the server, so we'll always use the default wallet
    // The client will handle wallet selection

    // Validate required fields
    if (!patientId || !description || !createdBy || !file) {
      return NextResponse.json(
        { message: "Patient ID, description, creator ID, and file are required" },
        { status: 400 },
      )
    }

    // Process file
    const fileBuffer = Buffer.from(await file.arrayBuffer())
    const fileName = `${uuidv4()}-${file.name}`
    const filePath = path.join(uploadsDir, fileName)

    // Save file to disk
    fs.writeFileSync(filePath, fileBuffer)

    // Create record in database
    const recordData = {
      patient_id: patientId,
      description,
      file_name: file.name,
      file_type: file.type,
      file_size: file.size,
      file_path: filePath,
      created_by: createdBy,
    }

    const newRecord = await createMedicalRecord(recordData)

    if (!newRecord) {
      return NextResponse.json({ message: "Failed to create medical record" }, { status: 500 })
    }

    // Get user details for audit log
    const userDetails = await getUserById(createdBy)
    const patientDetails = await getUserById(patientId)

    // Log the record creation to blockchain
    try {
      // Always use the default wallet for server-side operations
      const result = await logRecordAdded(newRecord.id, newRecord.hash, patientId, createdBy)

      // If successful, update the record with the transaction hash
      if (result.success && result.txHash) {
        await updateRecordBlockchainTx(newRecord.id, result.txHash)
      }

      // Log audit event
      try {
        await logAuditEvent({
          action_type: "RECORD_CREATED",
          record_id: newRecord.id,
          user_id: createdBy,
          user_name: userDetails?.name || "Unknown User",
          user_role: userDetails?.role || "unknown",
          patient_id: patientId,
          description: description,
          details: {
            file_name: file.name,
            file_size: file.size,
            file_type: file.type,
          },
          blockchain_tx: result.txHash || undefined,
        })
      } catch (auditError) {
        console.error("Error logging audit event:", auditError)
      }

      return NextResponse.json({
        message: "Medical record created successfully",
        record: {
          id: newRecord.id,
          description: newRecord.description,
        },
        blockchain_recorded: result.success,
        txHash: result.txHash,
      })
    } catch (blockchainError) {
      console.error("Blockchain logging error:", blockchainError)
      // Continue even if blockchain logging fails
      return NextResponse.json({
        message: "Medical record created successfully, but blockchain recording failed",
        record: {
          id: newRecord.id,
          description: newRecord.description,
        },
        blockchain_recorded: false,
      })
    }
  } catch (error) {
    console.error("Create medical record error:", error)
    return NextResponse.json({ message: "An error occurred while creating the medical record" }, { status: 500 })
  }
}
