import { type NextRequest, NextResponse } from "next/server"
import { deleteMedicalRecord, getMedicalRecord, getUserById } from "@/lib/db"
import { requireAuth } from "@/lib/auth"
import { logAuditEvent } from "@/lib/audit-log"
import { logRecordDeleted } from "@/lib/blockchain/contract"
import fs from "fs"

export async function DELETE(request: NextRequest) {
  try {
    // Check if user is authorized
    const user = await requireAuth(["admin", "doctor"])

    const { recordId } = await request.json()

    if (!recordId) {
      return NextResponse.json({ message: "Record ID is required" }, { status: 400 })
    }

    // Get record to check file path
    const record = await getMedicalRecord(recordId)

    if (!record) {
      return NextResponse.json({ message: "Record not found" }, { status: 404 })
    }

    // Delete file if it exists
    if (record.file_path && fs.existsSync(record.file_path)) {
      try {
        fs.unlinkSync(record.file_path)
      } catch (fileError) {
        console.error("Error deleting file:", fileError)
        // Continue even if file deletion fails
      }
    }

    // Delete record from database
    const success = await deleteMedicalRecord(recordId)

    if (!success) {
      return NextResponse.json({ message: "Failed to delete medical record" }, { status: 500 })
    }

    // Get user details for audit log
    const userDetails = await getUserById(user.id)

    // Log the record deletion to blockchain and capture the transaction hash
    let blockchainTxHash: string | undefined = undefined
    try {
      // Always use the default wallet for server-side operations
      const result: any = await logRecordDeleted(recordId, false)
      blockchainTxHash = result.txHash
    } catch (blockchainError) {
      console.error("Blockchain logging error:", blockchainError)
      // Continue even if blockchain logging fails
    }

    // Log audit event - record permanent deletion even though record is gone
    try {
      await logAuditEvent({
        action_type: "RECORD_DELETED",
        record_id: recordId,
        user_id: user.id,
        user_name: userDetails?.name || user.name,
        user_role: user.role,
        patient_id: record.patient_id,
        description: `Record deleted by ${user.role}: ${record.description}`,
        details: {
          deleted_record_hash: record.hash,
          file_name: record.file_name,
          file_size: record.file_size,
        },
        blockchain_tx: blockchainTxHash,
      })
    } catch (auditError) {
      console.error("Error logging audit event:", auditError)
    }

    return NextResponse.json({
      message: "Medical record deleted successfully",
      success: true,
      blockchain_recorded: true,
    })
  } catch (error) {
    console.error("Delete medical record error:", error)
    return NextResponse.json(
      {
        message: "An error occurred while deleting the medical record",
        success: false,
      },
      { status: 500 },
    )
  }
}
