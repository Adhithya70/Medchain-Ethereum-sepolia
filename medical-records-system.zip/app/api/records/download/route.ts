import { type NextRequest, NextResponse } from "next/server"
import { getMedicalRecord, getUserById } from "@/lib/db"
import { requireAuth } from "@/lib/auth"
import { logAuditEvent } from "@/lib/audit-log"
import { logRecordApproved } from "@/lib/blockchain/contract"
import fs from "fs"

export async function GET(request: NextRequest) {
  try {
    // Check if user is authorized
    const user = await requireAuth(["admin", "patient", "doctor"])

    // Get the record ID from the query parameters
    const searchParams = request.nextUrl.searchParams
    const recordId = searchParams.get("recordId")

    if (!recordId) {
      return NextResponse.json({ message: "Record ID is required" }, { status: 400 })
    }

    // Get the record
    const record = await getMedicalRecord(recordId)

    if (!record) {
      return NextResponse.json({ message: "Record not found" }, { status: 404 })
    }

    // If user is a patient, check if they own the record
    if (user.role === "patient" && record.patient_id !== user.id) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 403 })
    }

    // Check if file exists
    if (!record.file_path || !fs.existsSync(record.file_path)) {
      return NextResponse.json({ message: "File not found" }, { status: 404 })
    }

    // Get user details for audit log
    const userDetails = await getUserById(user.id)

    // Log the record download to blockchain for ALL users (admin, patient, doctor) and capture tx hash
    let blockchainTxHash: string | undefined = undefined
    try {
      const result: any = await logRecordApproved(recordId, record.hash)
      blockchainTxHash = result.txHash
    } catch (blockchainError) {
      console.error("Blockchain logging error:", blockchainError)
      // Continue even if blockchain logging fails
    }

    // Log audit event for download
    try {
      await logAuditEvent({
        action_type: "DOWNLOAD_COMPLETED",
        record_id: recordId,
        user_id: user.id,
        user_name: userDetails?.name || user.name,
        user_role: user.role,
        patient_id: record.patient_id,
        description: `Record downloaded by ${user.role}: ${record.description}`,
        details: {
          file_name: record.file_name,
          file_size: record.file_size,
          file_type: record.file_type,
        },
        blockchain_tx: blockchainTxHash,
      })
    } catch (auditError) {
      console.error("Error logging audit event:", auditError)
    }

    // Read the file
    const fileBuffer = fs.readFileSync(record.file_path)

    // Determine content type
    const contentType = record.file_type || "application/octet-stream"

    // Return the file
    return new NextResponse(fileBuffer, {
      headers: {
        "Content-Type": contentType,
        "Content-Disposition": `attachment; filename="${record.file_name || `record-${recordId}.pdf`}"`,
      },
    })
  } catch (error) {
    console.error("Download record error:", error)
    return NextResponse.json({ message: "An error occurred while downloading the record" }, { status: 500 })
  }
}
