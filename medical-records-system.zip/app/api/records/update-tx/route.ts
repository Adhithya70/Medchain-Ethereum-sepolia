import { type NextRequest, NextResponse } from "next/server"
import { updateRecordBlockchainTx } from "@/lib/db"
import { requireAuth } from "@/lib/auth"

export async function POST(request: NextRequest) {
  try {
    // Check if user is authorized
    const user = await requireAuth(["admin", "doctor"])

    const { recordId, txHash } = await request.json()

    // Validate required fields
    if (!recordId || !txHash) {
      return NextResponse.json({ message: "Record ID and transaction hash are required" }, { status: 400 })
    }

    // Update the record with the transaction hash
    const updated = await updateRecordBlockchainTx(recordId, txHash)

    if (!updated) {
      return NextResponse.json({ message: "Failed to update record transaction hash" }, { status: 500 })
    }

    return NextResponse.json({
      message: "Record transaction hash updated successfully",
      success: true,
    })
  } catch (error) {
    console.error("Update record transaction hash error:", error)
    return NextResponse.json({ message: "An error occurred while updating the record" }, { status: 500 })
  }
}
