import { type NextRequest, NextResponse } from "next/server"
import { deleteUser, getUserById } from "@/lib/db"
import { requireAuth } from "@/lib/auth"

export async function DELETE(request: NextRequest) {
  try {
    // Check if user is admin
    const user = await requireAuth(["admin"])

    const { userId } = await request.json()

    if (!userId) {
      return NextResponse.json({ message: "User ID is required" }, { status: 400 })
    }

    // Check if user exists
    const userToDelete = await getUserById(userId)

    if (!userToDelete) {
      return NextResponse.json({ message: "User not found" }, { status: 404 })
    }

    // Prevent deleting admin
    if (userToDelete.role === "admin") {
      return NextResponse.json({ message: "Cannot delete admin user" }, { status: 403 })
    }

    // Delete user
    const success = await deleteUser(userId)

    if (!success) {
      return NextResponse.json({ message: "Failed to delete user" }, { status: 500 })
    }

    return NextResponse.json({
      message: "User deleted successfully",
    })
  } catch (error) {
    console.error("Delete user error:", error)
    return NextResponse.json({ message: "An error occurred while deleting the user" }, { status: 500 })
  }
}
