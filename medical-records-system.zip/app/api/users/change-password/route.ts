import { type NextRequest, NextResponse } from "next/server"
import { requireAuth } from "@/lib/auth"
import { pool } from "@/lib/db/db"

export async function POST(request: NextRequest) {
  try {
    // Check if user is authenticated
    const authUser = await requireAuth()

    const { userId, currentPassword, newPassword } = await request.json()

    // Validate input
    if (!userId || !currentPassword || !newPassword) {
      return NextResponse.json({ message: "All fields are required" }, { status: 400 })
    }

    // Ensure user can only change their own password unless they're an admin
    if (authUser.id !== userId && authUser.role !== "admin") {
      return NextResponse.json({ message: "Unauthorized" }, { status: 403 })
    }

    // Verify current password
    const [rows]: any = await pool.query("SELECT * FROM users WHERE id = ?", [userId])

    if (rows.length === 0) {
      return NextResponse.json({ message: "User not found" }, { status: 404 })
    }

    const user = rows[0]

    if (user.password !== currentPassword) {
      return NextResponse.json({ message: "Current password is incorrect" }, { status: 401 })
    }

    // Update password
    await pool.query("UPDATE users SET password = ? WHERE id = ?", [newPassword, userId])

    return NextResponse.json({
      message: "Password changed successfully",
    })
  } catch (error) {
    console.error("Change password error:", error)
    return NextResponse.json({ message: "An error occurred while changing the password" }, { status: 500 })
  }
}
