import { NextResponse } from "next/server"
import { clearUserSession } from "@/lib/auth"

export async function POST() {
  try {
    await clearUserSession()
    // Redirect to login page after logout
    return NextResponse.redirect(new URL("/login/admin", process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000"), {
      status: 302,
    })
  } catch (error) {
    console.error("Logout error:", error)
    // Still redirect to login even if there's an error
    return NextResponse.redirect(new URL("/login/admin", process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000"), {
      status: 302,
    })
  }
}
