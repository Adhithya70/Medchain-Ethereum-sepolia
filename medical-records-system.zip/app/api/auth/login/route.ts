import { type NextRequest, NextResponse } from "next/server"
import { authenticateUser } from "@/lib/db"
import { setUserSession } from "@/lib/auth"

export async function POST(request: NextRequest) {
  try {
    const { userId, password, role } = await request.json()

    if (!userId || !password || !role) {
      return NextResponse.json({ message: "User ID, password, and role are required" }, { status: 400 })
    }

    const user = await authenticateUser(userId, password, role)

    if (!user) {
      return NextResponse.json({ message: "Invalid credentials" }, { status: 401 })
    }

    // Set user session
    await setUserSession(user)

    return NextResponse.json({
      message: "Login successful",
      user: {
        id: user.id,
        name: user.name,
        role: user.role,
      },
    })
  } catch (error) {
    console.error("Login error:", error)
    return NextResponse.json({ message: "An error occurred during login" }, { status: 500 })
  }
}
