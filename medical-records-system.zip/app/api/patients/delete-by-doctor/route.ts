import { type NextRequest, NextResponse } from "next/server"
import { deleteUser, getUserById } from "@/lib/db"
import { requireAuth } from "@/lib/auth"

export async function DELETE(request: NextRequest) {
  try {
    // Check if user is doctor
    const user = await requireAuth(["doctor"])

    const { patientId } = await request.json()

    if (!patientId) {
      return NextResponse.json({ message: "Patient ID is required" }, { status: 400 })
    }

    // Check if patient exists
    const patientToDelete = await getUserById(patientId)

    if (!patientToDelete) {
      return NextResponse.json({ message: "Patient not found" }, { status: 404 })
    }

    // Verify patient is a patient
    if (patientToDelete.role !== "patient") {
      return NextResponse.json({ message: "User is not a patient" }, { status: 400 })
    }

    // Delete patient
    const success = await deleteUser(patientId)

    if (!success) {
      return NextResponse.json({ message: "Failed to delete patient" }, { status: 500 })
    }

    return NextResponse.json({
      message: "Patient deleted successfully",
    })
  } catch (error) {
    console.error("Delete patient error:", error)
    return NextResponse.json({ message: "An error occurred while deleting the patient" }, { status: 500 })
  }
}
