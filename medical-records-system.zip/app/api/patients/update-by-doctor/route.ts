import { type NextRequest, NextResponse } from "next/server"
import { updateUser, getUserById } from "@/lib/db"
import { requireAuth } from "@/lib/auth"

export async function PUT(request: NextRequest) {
  try {
    // Check if user is doctor
    const user = await requireAuth(["doctor"])

    const userData = await request.json()
    const { id, doctorId } = userData

    if (!id) {
      return NextResponse.json({ message: "Patient ID is required" }, { status: 400 })
    }

    // Verify doctor is making the request
    if (doctorId !== user.id) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 403 })
    }

    // Check if patient exists
    const existingPatient = await getUserById(id)
    if (!existingPatient || existingPatient.role !== "patient") {
      return NextResponse.json({ message: "Patient not found" }, { status: 404 })
    }

    // Update patient
    const updatedPatient = await updateUser(id, userData)

    if (!updatedPatient) {
      return NextResponse.json({ message: "Failed to update patient" }, { status: 500 })
    }

    return NextResponse.json({
      message: "Patient updated successfully",
      patient: {
        id: updatedPatient.id,
        name: updatedPatient.name,
      },
    })
  } catch (error) {
    console.error("Update patient error:", error)
    return NextResponse.json({ message: "An error occurred while updating the patient" }, { status: 500 })
  }
}
