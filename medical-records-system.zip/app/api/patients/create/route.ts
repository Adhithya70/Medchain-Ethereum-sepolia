import { type NextRequest, NextResponse } from "next/server"
import { createUser } from "@/lib/db"
import { requireAuth } from "@/lib/auth"

export async function POST(request: NextRequest) {
  try {
    // Check if user is admin
    const user = await requireAuth(["admin"])

    const formData = await request.formData()

    const patientData = {
      id: formData.get("id") as string,
      name: formData.get("name") as string,
      password: formData.get("password") as string,
      role: "patient",
      age: formData.get("age") ? Number.parseInt(formData.get("age") as string) : null,
      sex: formData.get("sex") as string,
      blood_group: formData.get("blood_group") as string,
      remarks: formData.get("remarks") as string,
    }

    // Validate required fields
    if (!patientData.id || !patientData.name || !patientData.password) {
      return NextResponse.json({ message: "ID, name, and password are required" }, { status: 400 })
    }

    const newPatient = await createUser(patientData)

    if (!newPatient) {
      return NextResponse.json({ message: "Failed to create patient" }, { status: 500 })
    }

    return NextResponse.json({
      message: "Patient created successfully",
      patient: {
        id: newPatient.id,
        name: newPatient.name,
      },
    })
  } catch (error) {
    console.error("Create patient error:", error)
    return NextResponse.json({ message: "An error occurred while creating the patient" }, { status: 500 })
  }
}
