import { type NextRequest, NextResponse } from "next/server"
import { updateUser } from "@/lib/db"
import { requireAuth } from "@/lib/auth"

export async function PUT(request: NextRequest) {
  try {
    // Check if user is patient
    const user = await requireAuth(["patient"])

    const userData = await request.json()

    // Update patient's own profile
    const updatedPatient = await updateUser(user.id, userData)

    if (!updatedPatient) {
      return NextResponse.json({ message: "Failed to update profile" }, { status: 500 })
    }

    return NextResponse.json({
      message: "Profile updated successfully",
      patient: {
        id: updatedPatient.id,
        name: updatedPatient.name,
      },
    })
  } catch (error) {
    console.error("Update profile error:", error)
    return NextResponse.json({ message: "An error occurred while updating your profile" }, { status: 500 })
  }
}
