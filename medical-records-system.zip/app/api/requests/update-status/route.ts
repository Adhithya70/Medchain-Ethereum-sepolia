import { type NextRequest, NextResponse } from "next/server"
import { updateRequestStatus, getUserById } from "@/lib/db"
import { requireAuth } from "@/lib/auth"
import { logAuditEvent } from "@/lib/audit-log"
import { logRequestApproved, logRequestRejected } from "@/lib/blockchain/contract"
import { pool } from "@/lib/db/db"

export async function POST(request: NextRequest) {
  try {
    // Check if user is admin or patient (patients can mark their own requests as downloaded)
    const user = await requireAuth(["admin", "patient"])

    const { requestId, status } = await request.json()

    // Validate required fields
    if (!requestId) {
      return NextResponse.json({ message: "Request ID is required" }, { status: 400 })
    }
    if (!status) {
      return NextResponse.json({ message: "Request ID and status are required" }, { status: 400 })
    }

    // Validate status
    if (!["approved", "rejected", "downloaded"].includes(status)) {
      return NextResponse.json({ message: "Invalid status" }, { status: 400 })
    }

    // Get the request to verify ownership and for blockchain logging
    const [rows]: any = await pool.query("SELECT * FROM download_requests WHERE id = ?", [requestId])
    const requestData = rows.length > 0 ? rows[0] : null

    if (!requestData) {
      return NextResponse.json({ message: "Request not found" }, { status: 404 })
    }

    // If patient, verify they own the request
    if (user.role === "patient" && status === "downloaded") {
      if (requestData.patient_id !== user.id) {
        return NextResponse.json({ message: "Unauthorized" }, { status: 403 })
      }
    }

    // Update request status
    const success = await updateRequestStatus(requestId, status)

    if (!success) {
      console.error(`Failed to update request ${requestId} to status: ${status}`)
      return NextResponse.json({ message: "Failed to update request status" }, { status: 500 })
    }

    // Log the request status update to blockchain and capture the transaction hash
    let blockchainRecorded = false
    let txHash: string | undefined = undefined
    try {
      if (status === "approved") {
        const result: any = await logRequestApproved(requestId)
        blockchainRecorded = result.success || false
        txHash = result.txHash
      } else if (status === "rejected") {
        const result: any = await logRequestRejected(requestId)
        blockchainRecorded = result.success || false
        txHash = result.txHash
      }
      // Note: We don't log "downloaded" status to blockchain as it's not in the contract
    } catch (blockchainError) {
      console.error("Blockchain logging error:", blockchainError)
      // Continue even if blockchain logging fails
    }

    // Get actor and patient details for audit log
    const actorDetails = await getUserById(user.id)
    const patientDetails = await getUserById(requestData.patient_id)

    // Log audit event - map status to action type
    const actionTypeMap: Record<string, any> = {
      approved: "DOWNLOAD_APPROVED",
      rejected: "DOWNLOAD_REJECTED",
      downloaded: "DOWNLOAD_COMPLETED",
    }

    try {
      await logAuditEvent({
        action_type: actionTypeMap[status],
        request_id: requestId,
        record_id: requestData.record_id,
        user_id: user.id,
        user_name: actorDetails?.name || user.name,
        user_role: user.role,
        actor_user_id: user.id,
        actor_user_name: actorDetails?.name || user.name,
        actor_user_role: user.role,
        patient_id: requestData.patient_id,
        description: `Download request ${status} by ${user.role}`,
        details: {
          old_status: requestData.status,
          new_status: status,
          record_description: requestData.record_description,
          record_hash: requestData.record_hash,
        },
        blockchain_tx: txHash,
      })
    } catch (auditError) {
      console.error("Error logging audit event:", auditError)
    }

    console.log(`Successfully updated request ${requestId} to status: ${status}`)

    return NextResponse.json({
      message: `Request ${status} successfully`,
      blockchain_recorded: blockchainRecorded,
    })
  } catch (error) {
    console.error("Update request status error:", error)
    return NextResponse.json({ message: "An error occurred while updating the request status" }, { status: 500 })
  }
}
