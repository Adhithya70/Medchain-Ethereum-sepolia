import { type NextRequest, NextResponse } from "next/server"
import { createDownloadRequest, getUserById, getMedicalRecord } from "@/lib/db"
import { requireAuth } from "@/lib/auth"
import { logAuditEvent } from "@/lib/audit-log"
import { logRequestSubmitted } from "@/lib/blockchain/contract"

export async function POST(request: NextRequest) {
  try {
    // Check if user is patient
    const user = await requireAuth(["patient"])

    const { patientId, recordId, recordHash, recordDescription, reason } = await request.json()

    // Validate required fields
    if (!patientId || !recordId || !recordHash || !recordDescription) {
      return NextResponse.json({ message: "All fields are required" }, { status: 400 })
    }

    // Verify that the patient is requesting their own record
    if (patientId !== user.id) {
      return NextResponse.json({ message: "Unauthorized request" }, { status: 403 })
    }

    // Create download request
    const requestData = {
      patient_id: patientId,
      record_id: recordId,
      record_hash: recordHash,
      record_description: recordDescription,
      reason: reason || "No reason provided",
    }

    const newRequest = await createDownloadRequest(requestData)

    if (!newRequest) {
      return NextResponse.json({ message: "Failed to create download request" }, { status: 500 })
    }

    // Get user and record details for audit log
    const userDetails = await getUserById(user.id)
    const recordDetails = await getMedicalRecord(recordId)

    // Log the request submission to blockchain and capture the transaction hash
    let blockchainTxHash: string | undefined = undefined
    try {
      const result: any = await logRequestSubmitted(newRequest.id, recordHash, patientId)
      blockchainTxHash = result.txHash
    } catch (blockchainError) {
      console.error("Blockchain logging error:", blockchainError)
      // Continue even if blockchain logging fails
    }

    // Log audit event
    try {
      await logAuditEvent({
        action_type: "DOWNLOAD_REQUESTED",
        request_id: newRequest.id,
        record_id: recordId,
        user_id: user.id,
        user_name: userDetails?.name || user.name,
        user_role: user.role,
        patient_id: patientId,
        description: recordDescription || "Record download requested",
        details: {
          record_hash: recordHash,
          reason: reason || "No reason provided",
          requested_at: new Date().toISOString(),
        },
        blockchain_tx: blockchainTxHash,
      })
    } catch (auditError) {
      console.error("Error logging audit event:", auditError)
    }

    return NextResponse.json({
      message: "Download request created successfully",
      request: {
        id: newRequest.id,
        status: newRequest.status,
      },
      blockchain_recorded: true,
    })
  } catch (error) {
    console.error("Create download request error:", error)
    return NextResponse.json({ message: "An error occurred while creating the download request" }, { status: 500 })
  }
}
