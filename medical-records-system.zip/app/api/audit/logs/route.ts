import { type NextRequest, NextResponse } from "next/server"
import { requireAuth } from "@/lib/auth"
import { getAuditLogs, getRecordAuditTrail, getPatientAuditTrail, getUserActivityLog } from "@/lib/audit-log"

export async function GET(request: NextRequest) {
  try {
    // Check if user is authorized
    const user = await requireAuth(["admin"])

    const searchParams = request.nextUrl.searchParams
    const action_type = searchParams.get("action_type")
    const record_id = searchParams.get("record_id")
    const request_id = searchParams.get("request_id")
    const user_id = searchParams.get("user_id")
    const patient_id = searchParams.get("patient_id")
    const start_date = searchParams.get("start_date")
    const end_date = searchParams.get("end_date")
    const trail_type = searchParams.get("trail_type") // "record", "patient", "user"
    const limit = searchParams.get("limit") ? parseInt(searchParams.get("limit")!) : 100
    const offset = searchParams.get("offset") ? parseInt(searchParams.get("offset")!) : 0

    let logs = []

    // Handle specific trail types for record/patient/user history
    if (trail_type === "record" && record_id) {
      logs = await getRecordAuditTrail(record_id)
    } else if (trail_type === "patient" && patient_id) {
      logs = await getPatientAuditTrail(patient_id)
    } else if (trail_type === "user" && user_id) {
      logs = await getUserActivityLog(user_id)
    } else {
      // General audit log query
      logs = await getAuditLogs({
        action_type: action_type as any,
        record_id: record_id || undefined,
        request_id: request_id || undefined,
        user_id: user_id || undefined,
        patient_id: patient_id || undefined,
        start_date: start_date || undefined,
        end_date: end_date || undefined,
        limit,
        offset,
      })
    }

    return NextResponse.json({
      success: true,
      count: logs.length,
      logs,
    })
  } catch (error) {
    console.error("Error fetching audit logs:", error)
    return NextResponse.json(
      {
        success: false,
        message: "Failed to fetch audit logs",
        error: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
