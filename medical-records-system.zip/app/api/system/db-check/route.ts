import { NextResponse } from "next/server"
import pool from "@/lib/db"

export async function GET() {
  try {
    // Test the connection by running a simple query
    const connection = await pool.getConnection()
    await connection.ping()
    connection.release()

    return NextResponse.json(
      {
        status: "connected",
        message: "Database connection successful",
        timestamp: new Date().toISOString(),
      },
      { status: 200 }
    )
  } catch (error: any) {
    console.error("[DB Connection Error]:", error.message)
    return NextResponse.json(
      {
        status: "disconnected",
        message: "Database connection failed",
        error: error.message,
        timestamp: new Date().toISOString(),
      },
      { status: 500 }
    )
  }
}
