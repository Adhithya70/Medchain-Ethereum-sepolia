import { type NextRequest, NextResponse } from "next/server"
import { requireAuth } from "@/lib/auth"
import { updateUser } from "@/lib/db"

export async function POST(request: NextRequest) {
  try {
    // Verify authentication
    const user = await requireAuth(["doctor"])
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Get request body
    const data = await request.json()

    // Ensure the doctor can only update their own profile
    if (user.id !== data.id) {
      return NextResponse.json({ error: "Unauthorized to update this profile" }, { status: 403 })
    }

    // Update the doctor profile
    const updatedDoctor = await updateUser(data.id, {
      name: data.name,
      specialization: data.specialization,
      university: data.university,
      graduation_year: data.graduation_year,
      experience: data.experience,
      college: data.college,
      remarks: data.remarks,
    })

    if (!updatedDoctor) {
      return NextResponse.json({ error: "Failed to update doctor profile" }, { status: 500 })
    }

    return NextResponse.json({ success: true, doctor: updatedDoctor })
  } catch (error) {
    console.error("Error updating doctor profile:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
