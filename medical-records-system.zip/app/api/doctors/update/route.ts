import { type NextRequest, NextResponse } from "next/server"
import { updateUser, getUserById } from "@/lib/db"
import { requireAuth } from "@/lib/auth"

export async function PUT(request: NextRequest) {
  try {
    // Check if user is admin
    const user = await requireAuth(["admin"])

    const userData = await request.json()
    const { id } = userData

    if (!id) {
      return NextResponse.json({ message: "Doctor ID is required" }, { status: 400 })
    }

    // Check if doctor exists
    const existingDoctor = await getUserById(id)
    if (!existingDoctor || existingDoctor.role !== "doctor") {
      return NextResponse.json({ message: "Doctor not found" }, { status: 404 })
    }

    // Update doctor
    const updatedDoctor = await updateUser(id, userData)

    if (!updatedDoctor) {
      return NextResponse.json({ message: "Failed to update doctor" }, { status: 500 })
    }

    return NextResponse.json({
      message: "Doctor updated successfully",
      doctor: {
        id: updatedDoctor.id,
        name: updatedDoctor.name,
      },
    })
  } catch (error) {
    console.error("Update doctor error:", error)
    return NextResponse.json({ message: "An error occurred while updating the doctor" }, { status: 500 })
  }
}
