import { type NextRequest, NextResponse } from "next/server"
import { createUser } from "@/lib/db"
import { requireAuth } from "@/lib/auth"

export async function POST(request: NextRequest) {
  try {
    // Check if user is admin
    const user = await requireAuth(["admin"])

    const formData = await request.formData()

    const doctorData = {
      id: formData.get("id") as string,
      name: formData.get("name") as string,
      password: formData.get("password") as string,
      role: "doctor",
      specialization: formData.get("specialization") as string,
      university: formData.get("university") as string,
      graduation_year: formData.get("graduation_year") as string,
      experience: formData.get("experience") as string,
      college: formData.get("college") as string,
      joining_date: new Date(),
      remarks: formData.get("remarks") as string,
      // New fields
      age: formData.get("age") as string,
      sex: formData.get("sex") as string,
      blood_group: formData.get("blood_group") as string,
    }

    // Validate required fields
    if (!doctorData.id || !doctorData.name || !doctorData.password) {
      return NextResponse.json({ message: "ID, name, and password are required" }, { status: 400 })
    }

    const newDoctor = await createUser(doctorData)

    if (!newDoctor) {
      return NextResponse.json({ message: "Failed to create doctor" }, { status: 500 })
    }

    return NextResponse.json({
      message: "Doctor created successfully",
      doctor: {
        id: newDoctor.id,
        name: newDoctor.name,
      },
    })
  } catch (error) {
    console.error("Create doctor error:", error)
    return NextResponse.json({ message: "An error occurred while creating the doctor" }, { status: 500 })
  }
}
