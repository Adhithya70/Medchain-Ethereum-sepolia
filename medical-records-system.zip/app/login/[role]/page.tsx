import Link from "next/link"
import { LoginForm } from "@/components/login-form"
import { Button } from "@/components/ui/button"
import { ChevronLeft } from "lucide-react"
import { notFound } from "next/navigation"

// Valid roles for type checking
const validRoles = ["admin", "doctor", "patient"] as const
type ValidRole = (typeof validRoles)[number]

// Type guard function
function isValidRole(role: string): role is ValidRole {
  return validRoles.includes(role as ValidRole)
}

export default async function LoginPage({ params }: { params: Promise<{ role: string }> }) {
  // Properly await params - required in Next.js 15
  const { role } = await params

  // Validate role
  if (!isValidRole(role)) {
    return notFound()
  }

  return (
    <div className="flex flex-col min-h-screen bg-gradient-to-b from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900">
      <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center">
          <Link href="/">
            <Button variant="ghost" size="sm">
              <ChevronLeft className="mr-2 h-4 w-4" />
              Back to Home
            </Button>
          </Link>
        </div>
      </header>

      <main className="flex-1 container flex items-center justify-center py-12">
        <LoginForm role={role} />
      </main>

      <footer className="border-t py-6">
        <div className="container flex justify-center">
          <p className="text-sm text-muted-foreground">&copy; {new Date().getFullYear()} Medical Records System</p>
        </div>
      </footer>
    </div>
  )
}
