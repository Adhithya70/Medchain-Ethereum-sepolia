import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"
import { Shield, UserRound, UserCog, ArrowRight, CheckCircle } from "lucide-react"
import { AnimatedGradientBackground } from "@/components/ui/animated-gradient-background"

export default function Home() {
  return (
    <AnimatedGradientBackground className="min-h-screen flex flex-col">
      <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-10">
        <div className="container flex h-16 items-center justify-between py-4">
          <h1 className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-purple-600">
            Medical Records System
          </h1>
          <div className="flex items-center gap-4">
            <Link href="/login/admin">
              <Button variant="ghost" size="sm">
                Admin
              </Button>
            </Link>
            <Link href="/login/doctor">
              <Button variant="ghost" size="sm">
                Doctor
              </Button>
            </Link>
            <Link href="/login/patient">
              <Button variant="ghost" size="sm">
                Patient
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <main className="flex-1 container py-12">
        <div className="max-w-3xl mx-auto text-center mb-12">
          <h2 className="text-4xl font-bold tracking-tight mb-4 bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-purple-600">
            Secure Medical Records Management
          </h2>
          <p className="text-muted-foreground text-lg">
            A blockchain-based platform for managing patient medical records with role-based access control.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
          <Card className="flex flex-col border-blue-200 dark:border-blue-800 shadow-lg hover:shadow-xl transition-all">
            <CardHeader className="text-center">
              <Shield className="w-12 h-12 mx-auto mb-2 text-blue-600" />
              <CardTitle>Admin</CardTitle>
              <CardDescription>System administration and oversight</CardDescription>
            </CardHeader>
            <CardContent className="flex-1">
              <ul className="space-y-2">
                <li className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-blue-600" />
                  <span>Manage doctors and patients</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-blue-600" />
                  <span>Approve download requests</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-blue-600" />
                  <span>View all medical records</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-blue-600" />
                  <span>System configuration</span>
                </li>
              </ul>
            </CardContent>
            <CardFooter>
              <Link href="/login/admin" className="w-full">
                <Button className="w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800">
                  Admin Login
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </CardFooter>
          </Card>

          <Card className="flex flex-col border-green-200 dark:border-green-800 shadow-lg hover:shadow-xl transition-all">
            <CardHeader className="text-center">
              <UserCog className="w-12 h-12 mx-auto mb-2 text-green-600" />
              <CardTitle>Doctor</CardTitle>
              <CardDescription>Medical professional access</CardDescription>
            </CardHeader>
            <CardContent className="flex-1">
              <ul className="space-y-2">
                <li className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  <span>Add and manage patients</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  <span>Upload medical records</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  <span>View patient information</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  <span>Update medical data</span>
                </li>
              </ul>
            </CardContent>
            <CardFooter>
              <Link href="/login/doctor" className="w-full">
                <Button className="w-full bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800">
                  Doctor Login
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </CardFooter>
          </Card>

          <Card className="flex flex-col border-purple-200 dark:border-purple-800 shadow-lg hover:shadow-xl transition-all">
            <CardHeader className="text-center">
              <UserRound className="w-12 h-12 mx-auto mb-2 text-purple-600" />
              <CardTitle>Patient</CardTitle>
              <CardDescription>Patient record access</CardDescription>
            </CardHeader>
            <CardContent className="flex-1">
              <ul className="space-y-2">
                <li className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-purple-600" />
                  <span>View personal medical records</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-purple-600" />
                  <span>Request record downloads</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-purple-600" />
                  <span>Track request status</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-purple-600" />
                  <span>Secure access to information</span>
                </li>
              </ul>
            </CardContent>
            <CardFooter>
              <Link href="/login/patient" className="w-full">
                <Button className="w-full bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800">
                  Patient Login
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </CardFooter>
          </Card>
        </div>

        <div className="mt-16 max-w-3xl mx-auto">
          <Card className="border-blue-100 dark:border-blue-900 bg-blue-50/50 dark:bg-blue-950/50">
            <CardContent className="p-6">
              <h3 className="text-xl font-semibold mb-2">Blockchain-Secured Records</h3>
              <p className="text-muted-foreground">
                Our system uses SHA-256 hashing to create unique identifiers for each medical record, ensuring data
                integrity and security. Every record is immutable and traceable, providing a reliable audit trail for
                sensitive medical information.
              </p>
            </CardContent>
          </Card>
        </div>
      </main>

      <footer className="border-t py-6 md:py-0 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex flex-col md:flex-row items-center justify-between gap-4 md:h-16">
          <p className="text-sm text-muted-foreground">
            &copy; {new Date().getFullYear()} Medical Records System. All rights reserved.
          </p>
          <div className="flex gap-4">
            <Link href="#" className="text-sm text-muted-foreground hover:text-foreground">
              Privacy Policy
            </Link>
            <Link href="#" className="text-sm text-muted-foreground hover:text-foreground">
              Terms of Service
            </Link>
            <Link href="#" className="text-sm text-muted-foreground hover:text-foreground">
              Contact
            </Link>
          </div>
        </div>
      </footer>
    </AnimatedGradientBackground>
  )
}
