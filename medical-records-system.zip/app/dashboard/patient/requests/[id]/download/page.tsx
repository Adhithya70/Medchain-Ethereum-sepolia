import { requireAuth } from "@/lib/auth"
import { DashboardHeader } from "@/components/dashboard-header"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { ChevronLeft, FileText } from "lucide-react"
import { getMedicalRecord, getRequestById } from "@/lib/db"
import { notFound } from "next/navigation"
import { DownloadRecordButton } from "@/components/download-record-button"

const navigation = [
  { name: "Dashboard", href: "/dashboard/patient" },
  { name: "Records", href: "/dashboard/patient/records" },
  { name: "Requests", href: "/dashboard/patient/requests" },
]

export default async function DownloadRecordPage({ params }: { params: Promise<{ id: string }> }) {
  const user = await requireAuth(["patient"])
  // Properly extract the ID from params - required in Next.js 15
  const { id: requestId } = await params

  // Fetch the actual request data from the database
  const request = await getRequestById(requestId)

  if (!request || request.status !== "approved" || request.patient_id !== user.id) {
    return notFound()
  }

  // Use the actual record_id from the request
  const recordId = request.record_id
  const record = await getMedicalRecord(recordId)

  if (!record || record.patient_id !== user.id) {
    return notFound()
  }

  return (
    <div className="flex min-h-screen flex-col">
      <DashboardHeader user={user} navigation={navigation} />

      <main className="flex-1 container py-6">
        <div className="flex flex-col gap-6">
          <div className="flex items-center gap-2">
            <Link href="/dashboard/patient/requests">
              <Button variant="outline" size="sm">
                <ChevronLeft className="mr-2 h-4 w-4" />
                Back to Requests
              </Button>
            </Link>
            <h1 className="text-3xl font-bold">Download Medical Record</h1>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Medical Record Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-4">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                  <FileText className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <p className="font-medium">{record.description}</p>
                  <p className="text-sm text-muted-foreground">
                    Added on {new Date(record.created_at).toLocaleDateString()}
                  </p>
                </div>
              </div>
              <div className="text-sm text-muted-foreground">
                <p>
                  Your download request has been approved. You can download this record once. If you need to download it
                  again, you will need to submit a new request.
                </p>
              </div>
            </CardContent>
            <CardFooter className="flex justify-end">
              <DownloadRecordButton recordId={record.id} requestId={requestId} />
            </CardFooter>
          </Card>
        </div>
      </main>
    </div>
  )
}
