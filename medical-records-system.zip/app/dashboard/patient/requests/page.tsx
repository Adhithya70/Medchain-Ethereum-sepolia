import { requireAuth } from "@/lib/auth"
import { DashboardHeader } from "@/components/dashboard-header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { getPatientRequests } from "@/lib/db"
import { Badge } from "@/components/ui/badge"
import { Download, Clock, CheckCircle, XCircle } from "lucide-react"
import Link from "next/link"

const navigation = [
  { name: "Dashboard", href: "/dashboard/patient" },
  { name: "Records", href: "/dashboard/patient/records" },
  { name: "Requests", href: "/dashboard/patient/requests" },
]

export default async function RequestsPage() {
  const user = await requireAuth(["patient"])
  const requests = await getPatientRequests(user.id)

  // Group requests by status
  const pendingRequests = requests.filter((req: any) => req.status === "pending")
  const approvedRequests = requests.filter((req: any) => req.status === "approved")
  const rejectedRequests = requests.filter((req: any) => req.status === "rejected")
  const downloadedRequests = requests.filter((req: any) => req.status === "downloaded")

  return (
    <div className="flex min-h-screen flex-col">
      <DashboardHeader user={user} navigation={navigation} />

      <main className="flex-1 container py-6">
        <div className="flex flex-col gap-6">
          <h1 className="text-3xl font-bold">Download Requests</h1>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Pending Requests</CardTitle>
              </CardHeader>
              <CardContent>
                {pendingRequests.length > 0 ? (
                  <div className="space-y-4">
                    {pendingRequests.map((request: any) => (
                      <div key={request.id} className="flex items-center justify-between border-b pb-4">
                        <div className="flex items-center gap-4">
                          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-yellow-100 dark:bg-yellow-900">
                            <Clock className="h-5 w-5 text-yellow-500" />
                          </div>
                          <div>
                            <p className="font-medium">{request.record_description}</p>
                            <p className="text-sm text-muted-foreground">
                              Requested on {new Date(request.requested_at).toLocaleDateString()}
                            </p>
                            <Badge variant="outline" className="mt-1 text-yellow-500 border-yellow-500">
                              Pending
                            </Badge>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-muted-foreground">No pending requests.</p>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Approved Requests</CardTitle>
              </CardHeader>
              <CardContent>
                {approvedRequests.length > 0 ? (
                  <div className="space-y-4">
                    {approvedRequests.map((request: any) => (
                      <div key={request.id} className="flex items-center justify-between border-b pb-4">
                        <div className="flex items-center gap-4">
                          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-green-100 dark:bg-green-900">
                            <CheckCircle className="h-5 w-5 text-green-500" />
                          </div>
                          <div>
                            <p className="font-medium">{request.record_description}</p>
                            <p className="text-sm text-muted-foreground">
                              Approved on {new Date(request.approved_at).toLocaleDateString()}
                            </p>
                            <Badge variant="outline" className="mt-1 text-green-500 border-green-500">
                              Approved
                            </Badge>
                          </div>
                        </div>
                        <Link href={`/dashboard/patient/requests/${request.id}/download`}>
                          <Button size="sm">
                            <Download className="mr-2 h-4 w-4" />
                            Download
                          </Button>
                        </Link>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-muted-foreground">No approved requests.</p>
                )}
              </CardContent>
            </Card>

            <Card className="md:col-span-2">
              <CardHeader>
                <CardTitle>Request History</CardTitle>
              </CardHeader>
              <CardContent>
                {rejectedRequests.length > 0 || downloadedRequests.length > 0 ? (
                  <div className="space-y-4">
                    {rejectedRequests.map((request: any) => (
                      <div key={request.id} className="flex items-center justify-between border-b pb-4">
                        <div className="flex items-center gap-4">
                          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-red-100 dark:bg-red-900">
                            <XCircle className="h-5 w-5 text-red-500" />
                          </div>
                          <div>
                            <p className="font-medium">{request.record_description}</p>
                            <p className="text-sm text-muted-foreground">
                              Rejected on {new Date(request.rejected_at).toLocaleDateString()}
                            </p>
                            <Badge variant="outline" className="mt-1 text-red-500 border-red-500">
                              Rejected
                            </Badge>
                          </div>
                        </div>
                      </div>
                    ))}

                    {downloadedRequests.map((request: any) => (
                      <div key={request.id} className="flex items-center justify-between border-b pb-4">
                        <div className="flex items-center gap-4">
                          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-blue-100 dark:bg-blue-900">
                            <Download className="h-5 w-5 text-blue-500" />
                          </div>
                          <div>
                            <p className="font-medium">{request.record_description}</p>
                            <p className="text-sm text-muted-foreground">
                              Downloaded on {new Date(request.downloaded_at).toLocaleDateString()}
                            </p>
                            <Badge variant="outline" className="mt-1 text-blue-500 border-blue-500">
                              Downloaded
                            </Badge>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-muted-foreground">No request history.</p>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}
