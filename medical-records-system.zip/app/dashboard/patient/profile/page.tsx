import { requireAuth } from "@/lib/auth"
import { DashboardHeader } from "@/components/dashboard-header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { getUserById } from "@/lib/db"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { Edit } from "lucide-react"

const navigation = [
  { name: "Dashboard", href: "/dashboard/patient" },
  { name: "Records", href: "/dashboard/patient/records" },
  { name: "Requests", href: "/dashboard/patient/requests" },
]

export default async function PatientProfilePage() {
  const user = await requireAuth(["patient"])

  // Get full patient details
  const patientDetails = await getUserById(user.id)

  return (
    <div className="flex min-h-screen flex-col">
      <DashboardHeader user={user} navigation={navigation} />

      <main className="flex-1 container py-6">
        <div className="flex flex-col gap-6">
          <div className="flex items-center justify-between">
            <h1 className="text-3xl font-bold">My Profile</h1>
            <Link href="/dashboard/patient/profile/edit">
              <Button variant="outline">
                <Edit className="mr-2 h-4 w-4" />
                Edit Profile
              </Button>
            </Link>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Patient Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-medium">Patient ID</p>
                  <p className="text-sm text-muted-foreground">{patientDetails.id}</p>
                </div>
                <div>
                  <p className="text-sm font-medium">Name</p>
                  <p className="text-sm text-muted-foreground">{patientDetails.name}</p>
                </div>
                <div>
                  <p className="text-sm font-medium">Age</p>
                  <p className="text-sm text-muted-foreground">{patientDetails.age || "Not specified"}</p>
                </div>
                <div>
                  <p className="text-sm font-medium">Sex</p>
                  <p className="text-sm text-muted-foreground">{patientDetails.sex || "Not specified"}</p>
                </div>
                <div>
                  <p className="text-sm font-medium">Blood Group</p>
                  <p className="text-sm text-muted-foreground">{patientDetails.blood_group || "Not specified"}</p>
                </div>
                <div>
                  <p className="text-sm font-medium">Registration Date</p>
                  <p className="text-sm text-muted-foreground">
                    {patientDetails.registration_date
                      ? new Date(patientDetails.registration_date).toLocaleDateString()
                      : "Not specified"}
                  </p>
                </div>
              </div>
              {patientDetails.remarks && (
                <div>
                  <p className="text-sm font-medium">Medical Remarks</p>
                  <p className="text-sm text-muted-foreground">{patientDetails.remarks}</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
