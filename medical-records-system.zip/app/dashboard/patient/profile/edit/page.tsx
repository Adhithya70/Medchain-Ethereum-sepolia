import { requireAuth } from "@/lib/auth"
import { DashboardHeader } from "@/components/dashboard-header"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { ChevronLeft } from "lucide-react"
import { getUserById } from "@/lib/db"
import { notFound } from "next/navigation"
import { EditPatientProfileForm } from "@/components/edit-patient-profile-form"

const navigation = [
  { name: "Dashboard", href: "/dashboard/patient" },
  { name: "Records", href: "/dashboard/patient/records" },
  { name: "Requests", href: "/dashboard/patient/requests" },
]

export default async function EditPatientProfilePage() {
  const user = await requireAuth(["patient"])
  const patientDetails = await getUserById(user.id)

  if (!patientDetails) {
    return notFound()
  }

  return (
    <div className="flex min-h-screen flex-col">
      <DashboardHeader user={user} navigation={navigation} />

      <main className="flex-1 container py-6">
        <div className="flex flex-col gap-6">
          <div className="flex items-center gap-2">
            <Link href="/dashboard/patient/profile">
              <Button variant="outline" size="sm">
                <ChevronLeft className="mr-2 h-4 w-4" />
                Back to Profile
              </Button>
            </Link>
            <h1 className="text-3xl font-bold">Edit Profile</h1>
          </div>

          <EditPatientProfileForm patient={patientDetails} />
        </div>
      </main>
    </div>
  )
}
