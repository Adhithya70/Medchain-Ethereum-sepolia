import { requireAuth } from "@/lib/auth"
import { DashboardHeader } from "@/components/dashboard-header"
import { CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { FileText, Download, Clock } from "lucide-react"
import { getPatientRecords, getPatientRequests } from "@/lib/db"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { StatCard } from "@/components/ui/stat-card"
import { GradientCard } from "@/components/ui/gradient-card"

const navigation = [
  { name: "Dashboard", href: "/dashboard/patient" },
  { name: "Records", href: "/dashboard/patient/records" },
  { name: "Requests", href: "/dashboard/patient/requests" },
]

export default async function PatientDashboard() {
  const user = await requireAuth(["patient"])
  const records = await getPatientRecords(user.id)
  const requests = await getPatientRequests(user.id)

  const pendingRequests = requests.filter((req: any) => req.status === "pending")
  const approvedRequests = requests.filter((req: any) => req.status === "approved")

  return (
    <div className="flex min-h-screen flex-col">
      <DashboardHeader user={user} navigation={navigation} />

      <main className="flex-1 container py-6">
        <div className="flex flex-col gap-6">
          <h1 className="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-purple-600 to-indigo-600">
            Patient Dashboard
          </h1>

          <div className="grid gap-4 md:grid-cols-3">
            <StatCard
              title="Medical Records"
              value={records.length}
              description="Total records in your file"
              icon={FileText}
              iconClassName="bg-purple-100 dark:bg-purple-900/30"
            />

            <StatCard
              title="Pending Requests"
              value={pendingRequests.length}
              description="Awaiting approval"
              icon={Clock}
              iconClassName="bg-amber-100 dark:bg-amber-900/30"
            />

            <StatCard
              title="Approved Downloads"
              value={approvedRequests.length}
              description="Ready for download"
              icon={Download}
              iconClassName="bg-green-100 dark:bg-green-900/30"
            />
          </div>

          <Tabs defaultValue="records" className="w-full">
            <TabsList className="mb-2">
              <TabsTrigger value="records">Medical Records</TabsTrigger>
              <TabsTrigger value="requests">Download Requests</TabsTrigger>
            </TabsList>
            <TabsContent value="records" className="space-y-4">
              <GradientCard gradient="purple">
                <CardHeader>
                  <CardTitle>Your Medical Records</CardTitle>
                  <CardDescription>View your medical records and request downloads.</CardDescription>
                </CardHeader>
                <CardContent>
                  {records.length > 0 ? (
                    <div className="space-y-4">
                      {records.slice(0, 5).map((record: any) => (
                        <div key={record.id} className="flex items-center justify-between">
                          <div>
                            <p className="font-medium">{record.description}</p>
                            <p className="text-sm text-muted-foreground">
                              Added by {record.creator_name} on {new Date(record.created_at).toLocaleDateString()}
                            </p>
                          </div>
                          <div className="flex gap-2">
                            <Link href={`/dashboard/patient/records/${record.id}`}>
                              <Button variant="outline" size="sm">
                                View
                              </Button>
                            </Link>
                            <Link href={`/dashboard/patient/records/${record.id}/request`}>
                              <Button size="sm" className="bg-purple-600 hover:bg-purple-700">
                                Request Download
                              </Button>
                            </Link>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-muted-foreground">No medical records found.</p>
                  )}

                  <div className="mt-4 flex justify-end">
                    <Link href="/dashboard/patient/records">
                      <Button variant="outline">View All Records</Button>
                    </Link>
                  </div>
                </CardContent>
              </GradientCard>
            </TabsContent>

            <TabsContent value="requests" className="space-y-4">
              <GradientCard gradient="amber">
                <CardHeader>
                  <CardTitle>Download Requests</CardTitle>
                  <CardDescription>Status of your download requests.</CardDescription>
                </CardHeader>
                <CardContent>
                  {requests.length > 0 ? (
                    <div className="space-y-4">
                      {requests.slice(0, 5).map((request: any) => (
                        <div key={request.id} className="flex items-center justify-between">
                          <div>
                            <p className="font-medium">{request.record_description}</p>
                            <p className="text-sm text-muted-foreground">
                              Status:{" "}
                              <span
                                className={
                                  request.status === "approved"
                                    ? "text-green-500"
                                    : request.status === "rejected"
                                      ? "text-red-500"
                                      : "text-amber-500"
                                }
                              >
                                {request.status.charAt(0).toUpperCase() + request.status.slice(1)}
                              </span>
                            </p>
                          </div>
                          {request.status === "approved" && (
                            <Link href={`/dashboard/patient/requests/${request.id}/download`}>
                              <Button size="sm" className="bg-green-600 hover:bg-green-700">
                                Download
                              </Button>
                            </Link>
                          )}
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-muted-foreground">No download requests found.</p>
                  )}

                  <div className="mt-4 flex justify-end">
                    <Link href="/dashboard/patient/requests">
                      <Button variant="outline">View All Requests</Button>
                    </Link>
                  </div>
                </CardContent>
              </GradientCard>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}
