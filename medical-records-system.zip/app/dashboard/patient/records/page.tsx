import { requireAuth } from "@/lib/auth"
import { DashboardHeader } from "@/components/dashboard-header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { getPatientRecords } from "@/lib/db"
import { FileText } from "lucide-react"
import Link from "next/link"

const navigation = [
  { name: "Dashboard", href: "/dashboard/patient" },
  { name: "Records", href: "/dashboard/patient/records" },
  { name: "Requests", href: "/dashboard/patient/requests" },
]

export default async function RecordsPage() {
  const user = await requireAuth(["patient"])
  const records = await getPatientRecords(user.id)

  return (
    <div className="flex min-h-screen flex-col">
      <DashboardHeader user={user} navigation={navigation} />

      <main className="flex-1 container py-6">
        <div className="flex flex-col gap-6">
          <h1 className="text-3xl font-bold">My Medical Records</h1>

          <Card>
            <CardHeader>
              <CardTitle>All Records</CardTitle>
            </CardHeader>
            <CardContent>
              {records.length > 0 ? (
                <div className="space-y-4">
                  {records.map((record: any) => (
                    <div key={record.id} className="flex items-center justify-between border-b pb-4">
                      <div className="flex items-center gap-4">
                        <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                          <FileText className="h-6 w-6 text-primary" />
                        </div>
                        <div>
                          <p className="font-medium">{record.description}</p>
                          <p className="text-sm text-muted-foreground">
                            Added by {record.creator_name} on {new Date(record.created_at).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Link href={`/dashboard/patient/records/${record.id}`}>
                          <Button variant="outline" size="sm">
                            View Details
                          </Button>
                        </Link>
                        <Link href={`/dashboard/patient/records/${record.id}/request`}>
                          <Button size="sm">Request Download</Button>
                        </Link>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-12 text-center">
                  <FileText className="h-12 w-12 text-muted-foreground mb-4" />
                  <h3 className="text-lg font-medium">No records found</h3>
                  <p className="text-sm text-muted-foreground mt-1">
                    You don't have any medical records in the system yet.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
