import { requireAuth } from "@/lib/auth"
import { DashboardHeader } from "@/components/dashboard-header"
import { BlockchainAuditDashboard } from "@/components/blockchain-audit-dashboard"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { CONTRACT_ADDRESS } from "@/lib/blockchain/contract"

const navigation = [
  { name: "Dashboard", href: "/dashboard/admin" },
  { name: "Doctors", href: "/dashboard/admin/doctors" },
  { name: "Patients", href: "/dashboard/admin/patients" },
  { name: "Records", href: "/dashboard/admin/records" },
  { name: "Requests", href: "/dashboard/admin/requests" },
]

export default async function BlockchainActivityPage() {
  const user = await requireAuth(["admin"])

  const sepoliaExplorerUrl = `https://sepolia.etherscan.io/address/${CONTRACT_ADDRESS}`

  return (
    <div className="flex min-h-screen flex-col">
      <DashboardHeader user={user} navigation={navigation} />

      <main className="flex-1 container py-6">
        <div className="flex flex-col gap-6">
          <h1 className="text-3xl font-bold">Blockchain Activity & Audit Trail</h1>

          <Card>
            <CardHeader>
              <CardTitle>Sepolia Network Smart Contract</CardTitle>
              <CardDescription>
                View all transactions related to the medical records system on the Sepolia test network.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="p-4 bg-muted rounded-lg">
                <p className="font-medium">Smart Contract Address:</p>
                <p className="font-mono text-sm break-all">{CONTRACT_ADDRESS}</p>
              </div>

              <div className="flex flex-col gap-2">
                <p>
                  All transactions are recorded on the Sepolia test network. You can view the full transaction history
                  by clicking the button below.
                </p>
                <a
                  href={sepoliaExplorerUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-primary text-primary-foreground hover:bg-primary/90 px-4 py-2 rounded-md text-center"
                >
                  View on Etherscan
                </a>
              </div>
            </CardContent>
          </Card>

          <BlockchainAuditDashboard />
        </div>
      </main>
    </div>
  )
}
