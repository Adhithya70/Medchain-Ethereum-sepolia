import { requireAuth } from "@/lib/auth"
import { DashboardHeader } from "@/components/dashboard-header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { ChevronLeft, Edit, FileText, Plus } from "lucide-react"
import { getUserById, getPatientRecords } from "@/lib/db"
import { notFound } from "next/navigation"
import { DeleteUserButton } from "@/components/delete-user-button"
import { DeleteRecordButton } from "@/components/delete-record-button"

const navigation = [
  { name: "Dashboard", href: "/dashboard/admin" },
  { name: "Doctors", href: "/dashboard/admin/doctors" },
  { name: "Patients", href: "/dashboard/admin/patients" },
  { name: "Requests", href: "/dashboard/admin/requests" },
]

export default async function PatientDetailsPage({ params }: { params: Promise<{ id: string }> }) {
  const user = await requireAuth(["admin"])
  // Properly await params - required in Next.js 15
  const { id: patientId } = await params

  const patient = await getUserById(patientId)

  if (!patient || patient.role !== "patient") {
    return notFound()
  }

  const records = await getPatientRecords(patientId)

  return (
    <div className="flex min-h-screen flex-col">
      <DashboardHeader user={user} navigation={navigation} />

      <main className="flex-1 container py-6">
        <div className="flex flex-col gap-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Link href="/dashboard/admin/patients">
                <Button variant="outline" size="sm">
                  <ChevronLeft className="mr-2 h-4 w-4" />
                  Back to Patients
                </Button>
              </Link>
              <h1 className="text-3xl font-bold">{patient.name}</h1>
            </div>
            <div className="flex gap-2">
              <Link href={`/dashboard/admin/patients/${patient.id}/edit`}>
                <Button variant="outline">
                  <Edit className="mr-2 h-4 w-4" />
                  Edit
                </Button>
              </Link>
              <DeleteUserButton userId={patient.id} userType="patient" />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="md:col-span-1">
              <CardHeader>
                <CardTitle>Patient Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <p className="text-sm font-medium">Patient ID</p>
                  <p className="text-sm text-muted-foreground">{patient.id}</p>
                </div>
                <div>
                  <p className="text-sm font-medium">Age</p>
                  <p className="text-sm text-muted-foreground">{patient.age || "Not specified"}</p>
                </div>
                <div>
                  <p className="text-sm font-medium">Sex</p>
                  <p className="text-sm text-muted-foreground">{patient.sex || "Not specified"}</p>
                </div>
                <div>
                  <p className="text-sm font-medium">Blood Group</p>
                  <p className="text-sm text-muted-foreground">{patient.blood_group || "Not specified"}</p>
                </div>
                <div>
                  <p className="text-sm font-medium">Registration Date</p>
                  <p className="text-sm text-muted-foreground">
                    {patient.registration_date
                      ? new Date(patient.registration_date).toLocaleDateString()
                      : "Not specified"}
                  </p>
                </div>
                {patient.remarks && (
                  <div>
                    <p className="text-sm font-medium">Medical Remarks</p>
                    <p className="text-sm text-muted-foreground">{patient.remarks}</p>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card className="md:col-span-2">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Medical Records</CardTitle>
                <Link href={`/dashboard/admin/records/new?patient=${patient.id}`}>
                  <Button size="sm">
                    <Plus className="mr-2 h-4 w-4" />
                    Add Record
                  </Button>
                </Link>
              </CardHeader>
              <CardContent>
                {records.length > 0 ? (
                  <div className="space-y-4">
                    {records.map((record: any) => (
                      <div key={record.id} className="flex items-center justify-between border-b pb-4">
                        <div className="flex items-center gap-4">
                          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                            <FileText className="h-5 w-5 text-primary" />
                          </div>
                          <div>
                            <p className="font-medium">{record.description}</p>
                            <p className="text-sm text-muted-foreground">
                              Added by {record.creator_name} on {new Date(record.created_at).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <Link href={`/dashboard/admin/records/${record.id}`}>
                            <Button variant="outline" size="sm">
                              View
                            </Button>
                          </Link>
                          <DeleteRecordButton recordId={record.id} />
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center py-8 text-center">
                    <FileText className="h-12 w-12 text-muted-foreground mb-4" />
                    <h3 className="text-lg font-medium">No records found</h3>
                    <p className="text-sm text-muted-foreground mt-1">Add a new medical record for this patient.</p>
                    <Link href={`/dashboard/admin/records/new?patient=${patient.id}`} className="mt-4">
                      <Button>
                        <Plus className="mr-2 h-4 w-4" />
                        Add Record
                      </Button>
                    </Link>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}
