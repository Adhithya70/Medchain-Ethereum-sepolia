import { requireAuth } from "@/lib/auth"
import { DashboardHeader } from "@/components/dashboard-header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { getPendingRequests } from "@/lib/db"
import { Search, Download } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { RequestActionButtons } from "@/components/request-action-buttons"

const navigation = [
  { name: "Dashboard", href: "/dashboard/admin" },
  { name: "Doctors", href: "/dashboard/admin/doctors" },
  { name: "Patients", href: "/dashboard/admin/patients" },
  { name: "Requests", href: "/dashboard/admin/requests" },
]

export default async function RequestsPage() {
  const user = await requireAuth(["admin"])
  const requests = await getPendingRequests()

  return (
    <div className="flex min-h-screen flex-col">
      <DashboardHeader user={user} navigation={navigation} />

      <main className="flex-1 container py-6">
        <div className="flex flex-col gap-6">
          <div className="flex items-center justify-between">
            <h1 className="text-3xl font-bold">Download Requests</h1>
          </div>

          <div className="flex items-center gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input type="search" placeholder="Search requests..." className="w-full bg-background pl-8" />
            </div>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Pending Requests</CardTitle>
            </CardHeader>
            <CardContent>
              {requests.length > 0 ? (
                <div className="space-y-4">
                  {requests.map((request: any) => (
                    <div key={request.id} className="flex items-center justify-between border-b pb-4">
                      <div className="flex items-center gap-4">
                        <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                          <Download className="h-6 w-6 text-primary" />
                        </div>
                        <div>
                          <p className="font-medium">{request.patient_name}</p>
                          <p className="text-sm text-muted-foreground">
                            Patient ID: {request.patient_id} • Record: {request.record_description}
                          </p>
                          <p className="text-xs text-muted-foreground mt-1">
                            Requested on {new Date(request.requested_at).toLocaleDateString()}
                          </p>
                          <div className="mt-1">
                            <Badge variant="outline" className="text-yellow-500 border-yellow-500">
                              Pending
                            </Badge>
                          </div>
                        </div>
                      </div>
                      <RequestActionButtons requestId={request.id} />
                    </div>
                  ))}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-12 text-center">
                  <Download className="h-12 w-12 text-muted-foreground mb-4" />
                  <h3 className="text-lg font-medium">No pending requests</h3>
                  <p className="text-sm text-muted-foreground mt-1">All download requests have been processed.</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
