import { requireAuth } from "@/lib/auth"
import { DashboardHeader } from "@/components/dashboard-header"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { getAuditLogById } from "@/lib/audit-log"
import { formatDistanceToNow } from "date-fns"

const navigation = [
  { name: "Dashboard", href: "/dashboard/admin" },
  { name: "Doctors", href: "/dashboard/admin/doctors" },
  { name: "Patients", href: "/dashboard/admin/patients" },
  { name: "Records", href: "/dashboard/admin/records" },
  { name: "Requests", href: "/dashboard/admin/requests" },
  { name: "Blockchain", href: "/dashboard/admin/blockchain" },
]

const actionTypeColors: Record<string, string> = {
  RECORD_CREATED: "bg-green-100 text-green-800",
  RECORD_DELETED: "bg-red-100 text-red-800",
  DOWNLOAD_REQUESTED: "bg-blue-100 text-blue-800",
  DOWNLOAD_APPROVED: "bg-emerald-100 text-emerald-800",
  DOWNLOAD_REJECTED: "bg-orange-100 text-orange-800",
  DOWNLOAD_COMPLETED: "bg-purple-100 text-purple-800",
  STATUS_CHANGED: "bg-yellow-100 text-yellow-800",
}

const actionTypeLabels: Record<string, string> = {
  RECORD_CREATED: "Record Created",
  RECORD_DELETED: "Record Deleted",
  DOWNLOAD_REQUESTED: "Download Requested",
  DOWNLOAD_APPROVED: "Download Approved",
  DOWNLOAD_REJECTED: "Download Rejected",
  DOWNLOAD_COMPLETED: "Download Completed",
  STATUS_CHANGED: "Status Changed",
}

interface PageProps {
  params: Promise<{ id: string }>
}

export default async function AuditDetailPage({ params }: PageProps) {
  const { id } = await params
  const user = await requireAuth(["admin"])

  const auditLog = await getAuditLogById(id)

  if (!auditLog) {
    return (
      <div className="flex min-h-screen flex-col">
        <DashboardHeader user={user} navigation={navigation} />
        <main className="flex-1 container py-6">
          <div className="flex flex-col gap-4">
            <Link href="/dashboard/admin/blockchain">
              <Button variant="outline">← Back to Blockchain</Button>
            </Link>
            <Card>
              <CardContent className="pt-6">
                <p className="text-muted-foreground">Audit log not found</p>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    )
  }

  const sepoliaExplorerUrl = auditLog.blockchain_tx
    ? `https://sepolia.etherscan.io/tx/${auditLog.blockchain_tx}`
    : null

  return (
    <div className="flex min-h-screen flex-col">
      <DashboardHeader user={user} navigation={navigation} />

      <main className="flex-1 container py-6">
        <div className="flex flex-col gap-6">
          <div className="flex items-center justify-between">
            <h1 className="text-3xl font-bold">Transaction Details</h1>
            <Link href="/dashboard/admin/blockchain">
              <Button variant="outline">← Back to Blockchain</Button>
            </Link>
          </div>

          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Transaction #{auditLog.id.slice(0, 8)}</CardTitle>
                  <CardDescription>
                    {formatDistanceToNow(new Date(auditLog.timestamp), { addSuffix: true })}
                  </CardDescription>
                </div>
                <Badge className={actionTypeColors[auditLog.action_type]}>
                  {actionTypeLabels[auditLog.action_type]}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Primary User Information */}
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground mb-2">Primary User</h3>
                  <div className="space-y-2">
                    <p className="font-medium">{auditLog.user_name}</p>
                    <p className="text-sm text-muted-foreground">ID: {auditLog.user_id}</p>
                    <Badge variant="secondary">{auditLog.user_role}</Badge>
                  </div>
                </div>

                {auditLog.actor_user_name && (
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground mb-2">Actor User</h3>
                    <div className="space-y-2">
                      <p className="font-medium">{auditLog.actor_user_name}</p>
                      <p className="text-sm text-muted-foreground">ID: {auditLog.actor_user_id}</p>
                      <Badge variant="secondary">{auditLog.actor_user_role}</Badge>
                    </div>
                  </div>
                )}
              </div>

              <hr />

              {/* Record Information */}
              <div className="grid md:grid-cols-2 gap-6">
                {auditLog.record_id && (
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground mb-2">Record ID</h3>
                    <code className="bg-muted px-3 py-2 rounded block text-sm break-all">
                      {auditLog.record_id}
                    </code>
                  </div>
                )}

                {auditLog.request_id && (
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground mb-2">Request ID</h3>
                    <code className="bg-muted px-3 py-2 rounded block text-sm break-all">
                      {auditLog.request_id}
                    </code>
                  </div>
                )}

                {auditLog.patient_id && (
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground mb-2">Patient ID</h3>
                    <code className="bg-muted px-3 py-2 rounded block text-sm break-all">
                      {auditLog.patient_id}
                    </code>
                  </div>
                )}
              </div>

              <hr />

              {/* Description */}
              {auditLog.description && (
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground mb-2">Description</h3>
                  <p className="text-sm">{auditLog.description}</p>
                </div>
              )}

              {/* Additional Details */}
              {auditLog.details && Object.keys(auditLog.details).length > 0 && (
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground mb-2">Additional Details</h3>
                  <div className="bg-muted p-4 rounded text-sm overflow-auto">
                    <pre>{JSON.stringify(auditLog.details, null, 2)}</pre>
                  </div>
                </div>
              )}

              <hr />

              {/* Blockchain Information */}
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground mb-2">Timestamp</h3>
                  <p className="text-sm font-mono">{new Date(auditLog.timestamp).toISOString()}</p>
                </div>

                {auditLog.blockchain_tx && (
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground mb-2">Blockchain Transaction</h3>
                    <a
                      href={sepoliaExplorerUrl || "#"}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-blue-600 hover:underline text-sm font-mono break-all"
                    >
                      {auditLog.blockchain_tx}
                    </a>
                  </div>
                )}

                {auditLog.blockchain_block_number && (
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground mb-2">Block Number</h3>
                    <a
                      href={`https://sepolia.etherscan.io/block/${auditLog.blockchain_block_number}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-blue-600 hover:underline text-sm font-mono"
                    >
                      {auditLog.blockchain_block_number}
                    </a>
                  </div>
                )}
              </div>

              <hr />

              {/* Immutability Status */}
              <div>
                <h3 className="text-sm font-medium text-muted-foreground mb-2">Status</h3>
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="bg-green-50">
                    ✓ Immutable Record
                  </Badge>
                  <span className="text-sm text-muted-foreground">
                    This transaction record is permanent and cannot be modified or deleted.
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
