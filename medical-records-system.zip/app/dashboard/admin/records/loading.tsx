import { DashboardHeader } from "@/components/dashboard-header"
import { Skeleton } from "@/components/ui/skeleton"

const navigation = [
  { name: "Dashboard", href: "/dashboard/admin" },
  { name: "Doctors", href: "/dashboard/admin/doctors" },
  { name: "Patients", href: "/dashboard/admin/patients" },
  { name: "Records", href: "/dashboard/admin/records" },
  { name: "Requests", href: "/dashboard/admin/requests" },
  { name: "Blockchain", href: "/dashboard/admin/blockchain" },
]

export default function Loading() {
  return (
    <div className="flex min-h-screen flex-col">
      <DashboardHeader user={{ id: "", username: "Loading...", role: "admin" }} navigation={navigation} />

      <main className="flex-1 container py-6">
        <div className="flex flex-col gap-6">
          <div className="flex justify-between items-center">
            <Skeleton className="h-10 w-48" />
            <Skeleton className="h-10 w-32" />
          </div>

          <div className="bg-white shadow-md rounded-lg overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm text-left">
                <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                  <tr>
                    <th className="px-6 py-3">
                      <Skeleton className="h-4 w-16" />
                    </th>
                    <th className="px-6 py-3">
                      <Skeleton className="h-4 w-20" />
                    </th>
                    <th className="px-6 py-3">
                      <Skeleton className="h-4 w-24" />
                    </th>
                    <th className="px-6 py-3">
                      <Skeleton className="h-4 w-20" />
                    </th>
                    <th className="px-6 py-3">
                      <Skeleton className="h-4 w-24" />
                    </th>
                    <th className="px-6 py-3">
                      <Skeleton className="h-4 w-16" />
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {Array.from({ length: 5 }).map((_, index) => (
                    <tr key={index} className="border-b">
                      <td className="px-6 py-4">
                        <Skeleton className="h-4 w-8" />
                      </td>
                      <td className="px-6 py-4">
                        <Skeleton className="h-4 w-24" />
                      </td>
                      <td className="px-6 py-4">
                        <Skeleton className="h-4 w-32" />
                      </td>
                      <td className="px-6 py-4">
                        <Skeleton className="h-4 w-20" />
                      </td>
                      <td className="px-6 py-4">
                        <Skeleton className="h-4 w-24" />
                      </td>
                      <td className="px-6 py-4">
                        <Skeleton className="h-8 w-16" />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
