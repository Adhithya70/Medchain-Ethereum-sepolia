import { requireAuth } from "@/lib/auth"
import { DashboardHeader } from "@/components/dashboard-header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { ChevronLeft, Edit } from "lucide-react"
import { getUserById } from "@/lib/db"
import { notFound } from "next/navigation"
import { DeleteUserButton } from "@/components/delete-user-button"

const navigation = [
  { name: "Dashboard", href: "/dashboard/admin" },
  { name: "Doctors", href: "/dashboard/admin/doctors" },
  { name: "Patients", href: "/dashboard/admin/patients" },
  { name: "Requests", href: "/dashboard/admin/requests" },
]

export default async function DoctorDetailsPage({ params }: { params: Promise<{ id: string }> }) {
  const user = await requireAuth(["admin"])
  // Properly await params - required in Next.js 15
  const { id: doctorId } = await params

  const doctor = await getUserById(doctorId)

  if (!doctor || doctor.role !== "doctor") {
    return notFound()
  }

  return (
    <div className="flex min-h-screen flex-col">
      <DashboardHeader user={user} navigation={navigation} />

      <main className="flex-1 container py-6">
        <div className="flex flex-col gap-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Link href="/dashboard/admin/doctors">
                <Button variant="outline" size="sm">
                  <ChevronLeft className="mr-2 h-4 w-4" />
                  Back to Doctors
                </Button>
              </Link>
              <h1 className="text-3xl font-bold">{doctor.name}</h1>
            </div>
            <div className="flex gap-2">
              <Link href={`/dashboard/admin/doctors/${doctor.id}/edit`}>
                <Button variant="outline">
                  <Edit className="mr-2 h-4 w-4" />
                  Edit
                </Button>
              </Link>
              <DeleteUserButton userId={doctor.id} userType="doctor" />
            </div>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Doctor Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-medium">Doctor ID</p>
                  <p className="text-sm text-muted-foreground">{doctor.id}</p>
                </div>
                <div>
                  <p className="text-sm font-medium">Name</p>
                  <p className="text-sm text-muted-foreground">{doctor.name}</p>
                </div>
                <div>
                  <p className="text-sm font-medium">Specialization</p>
                  <p className="text-sm text-muted-foreground">{doctor.specialization || "Not specified"}</p>
                </div>
                <div>
                  <p className="text-sm font-medium">Experience</p>
                  <p className="text-sm text-muted-foreground">{doctor.experience || "Not specified"}</p>
                </div>
                <div>
                  <p className="text-sm font-medium">University</p>
                  <p className="text-sm text-muted-foreground">{doctor.university || "Not specified"}</p>
                </div>
                <div>
                  <p className="text-sm font-medium">Graduation Year</p>
                  <p className="text-sm text-muted-foreground">{doctor.graduation_year || "Not specified"}</p>
                </div>
                <div>
                  <p className="text-sm font-medium">Medical College</p>
                  <p className="text-sm text-muted-foreground">{doctor.college || "Not specified"}</p>
                </div>
                <div>
                  <p className="text-sm font-medium">Joining Date</p>
                  <p className="text-sm text-muted-foreground">
                    {doctor.joining_date ? new Date(doctor.joining_date).toLocaleDateString() : "Not specified"}
                  </p>
                </div>
              </div>
              {doctor.remarks && (
                <div>
                  <p className="text-sm font-medium">Additional Remarks</p>
                  <p className="text-sm text-muted-foreground">{doctor.remarks}</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
