import { requireAuth } from "@/lib/auth"
import { DashboardHeader } from "@/components/dashboard-header"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { ChevronLeft } from "lucide-react"
import { getUserById } from "@/lib/db"
import { notFound } from "next/navigation"
import { EditDoctorForm } from "@/components/edit-doctor-form"

const navigation = [
  { name: "Dashboard", href: "/dashboard/admin" },
  { name: "Doctors", href: "/dashboard/admin/doctors" },
  { name: "Patients", href: "/dashboard/admin/patients" },
  { name: "Requests", href: "/dashboard/admin/requests" },
]

export default async function EditDoctorPage({ params }: { params: Promise<{ id: string }> }) {
  const user = await requireAuth(["admin"])
  const { id: doctorId } = await params

  const doctor = await getUserById(doctorId)

  if (!doctor || doctor.role !== "doctor") {
    return notFound()
  }

  return (
    <div className="flex min-h-screen flex-col">
      <DashboardHeader user={user} navigation={navigation} />

      <main className="flex-1 container py-6">
        <div className="flex flex-col gap-6">
          <div className="flex items-center gap-2">
            <Link href={`/dashboard/admin/doctors/${doctorId}`}>
              <Button variant="outline" size="sm">
                <ChevronLeft className="mr-2 h-4 w-4" />
                Back to Doctor Details
              </Button>
            </Link>
            <h1 className="text-3xl font-bold">Edit Doctor</h1>
          </div>

          <EditDoctorForm doctor={doctor} />
        </div>
      </main>
    </div>
  )
}
