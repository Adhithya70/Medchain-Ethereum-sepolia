import { requireAuth } from "@/lib/auth"
import { DashboardHeader } from "@/components/dashboard-header"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { StatCard } from "@/components/ui/stat-card"
import { GradientCard } from "@/components/ui/gradient-card"
import { Users, FileText, Download, Plus, Activity } from "lucide-react"
import Link from "next/link"
import { pool } from "@/lib/db/db"

const navigation = [
  { name: "Dashboard", href: "/dashboard/admin" },
  { name: "Doctors", href: "/dashboard/admin/doctors" },
  { name: "Patients", href: "/dashboard/admin/patients" },
  { name: "Records", href: "/dashboard/admin/records" },
  { name: "Requests", href: "/dashboard/admin/requests" },
  { name: "Blockchain", href: "/dashboard/admin/blockchain" },
]

async function getDashboardStats() {
  try {
    // Get doctor count
    const [doctorResult]: any = await pool.query("SELECT COUNT(*) as count FROM users WHERE role = 'doctor'")
    const doctorCount = doctorResult[0].count

    // Get patient count
    const [patientResult]: any = await pool.query("SELECT COUNT(*) as count FROM users WHERE role = 'patient'")
    const patientCount = patientResult[0].count

    // Get record count
    const [recordResult]: any = await pool.query("SELECT COUNT(*) as count FROM medical_records")
    const recordCount = recordResult[0].count

    // Get pending request count
    const [requestResult]: any = await pool.query(
      "SELECT COUNT(*) as count FROM download_requests WHERE status = 'pending'",
    )
    const pendingRequestCount = requestResult[0].count

    // Get recent records
    const [recentRecords]: any = await pool.query(
      `SELECT mr.id, mr.description, mr.created_at, u.name as patient_name
       FROM medical_records mr
       JOIN users u ON mr.patient_id = u.id
       ORDER BY mr.created_at DESC
       LIMIT 5`,
    )

    // Get recent requests
    const [recentRequests]: any = await pool.query(
      `SELECT dr.id, dr.record_id, dr.requested_at, dr.status, u.name as patient_name
       FROM download_requests dr
       JOIN users u ON dr.patient_id = u.id
       ORDER BY dr.requested_at DESC
       LIMIT 5`,
    )

    return {
      doctorCount,
      patientCount,
      recordCount,
      pendingRequestCount,
      recentRecords,
      recentRequests,
    }
  } catch (error) {
    console.error("Error fetching dashboard stats:", error)
    return {
      doctorCount: 0,
      patientCount: 0,
      recordCount: 0,
      pendingRequestCount: 0,
      recentRecords: [],
      recentRequests: [],
    }
  }
}

export default async function AdminDashboard() {
  const user = await requireAuth(["admin"])
  const stats = await getDashboardStats()

  return (
    <div className="flex min-h-screen flex-col">
      <DashboardHeader user={user} navigation={navigation} />

      <main className="flex-1 container py-6">
        <div className="flex flex-col gap-8">
          <div>
            <h1 className="text-3xl font-bold mb-2">Admin Dashboard</h1>
            <p className="text-muted-foreground">Welcome back! Here's an overview of your medical records system.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <StatCard
              title="Total Doctors"
              value={stats.doctorCount}
              icon={<Users className="h-5 w-5" />}
              description="Registered medical professionals"
              className="bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-950/50 dark:to-blue-900/30"
              iconClassName="bg-blue-100 text-blue-700 dark:bg-blue-900/50 dark:text-blue-400"
            />
            <StatCard
              title="Total Patients"
              value={stats.patientCount}
              icon={<Users className="h-5 w-5" />}
              description="Registered patients"
              className="bg-gradient-to-br from-purple-50 to-purple-100 dark:from-purple-950/50 dark:to-purple-900/30"
              iconClassName="bg-purple-100 text-purple-700 dark:bg-purple-900/50 dark:text-purple-400"
            />
            <StatCard
              title="Medical Records"
              value={stats.recordCount}
              icon={<FileText className="h-5 w-5" />}
              description="Total stored records"
              className="bg-gradient-to-br from-green-50 to-green-100 dark:from-green-950/50 dark:to-green-900/30"
              iconClassName="bg-green-100 text-green-700 dark:bg-green-900/50 dark:text-green-400"
            />
            <StatCard
              title="Pending Requests"
              value={stats.pendingRequestCount}
              icon={<Download className="h-5 w-5" />}
              description="Awaiting approval"
              className="bg-gradient-to-br from-amber-50 to-amber-100 dark:from-amber-950/50 dark:to-amber-900/30"
              iconClassName="bg-amber-100 text-amber-700 dark:bg-amber-900/50 dark:text-amber-400"
            />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <GradientCard className="from-blue-600 to-indigo-600">
              <CardHeader>
                <CardTitle className="text-white flex items-center justify-between">
                  <span>Quick Actions</span>
                  <Activity className="h-5 w-5 opacity-80" />
                </CardTitle>
                <CardDescription className="text-blue-100">Manage your medical records system</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <Link href="/dashboard/admin/doctors/new">
                    <Button className="w-full bg-white/20 hover:bg-white/30 text-white border-white/10">
                      <Plus className="mr-2 h-4 w-4" />
                      Add New Doctor
                    </Button>
                  </Link>
                  <Link href="/dashboard/admin/patients/new">
                    <Button className="w-full bg-white/20 hover:bg-white/30 text-white border-white/10">
                      <Plus className="mr-2 h-4 w-4" />
                      Add New Patient
                    </Button>
                  </Link>
                  <Link href="/dashboard/admin/records/new">
                    <Button className="w-full bg-white/20 hover:bg-white/30 text-white border-white/10">
                      <Plus className="mr-2 h-4 w-4" />
                      Add Medical Record
                    </Button>
                  </Link>
                  <Link href="/dashboard/admin/requests">
                    <Button className="w-full bg-white/20 hover:bg-white/30 text-white border-white/10">
                      <Download className="mr-2 h-4 w-4" />
                      View Requests
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </GradientCard>

            <Card className="shadow-md">
              <CardHeader>
                <CardTitle>Recent Records</CardTitle>
                <CardDescription>Latest medical records added to the system</CardDescription>
              </CardHeader>
              <CardContent>
                {stats.recentRecords.length > 0 ? (
                  <div className="space-y-4">
                    {stats.recentRecords.map((record: any) => (
                      <div key={record.id} className="flex items-center justify-between border-b pb-2">
                        <div>
                          <p className="font-medium">{record.description}</p>
                          <p className="text-sm text-muted-foreground">Patient: {record.patient_name}</p>
                        </div>
                        <Link href={`/dashboard/admin/records/${record.id}`}>
                          <Button variant="outline" size="sm">
                            View
                          </Button>
                        </Link>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-muted-foreground">No records found</p>
                )}
              </CardContent>
            </Card>
          </div>

          <Card className="shadow-md">
            <CardHeader>
              <CardTitle>Recent Download Requests</CardTitle>
              <CardDescription>Latest requests from patients to download their records</CardDescription>
            </CardHeader>
            <CardContent>
              {stats.recentRequests.length > 0 ? (
                <div className="relative overflow-x-auto">
                  <table className="w-full text-sm text-left">
                    <thead className="text-xs uppercase bg-muted/50">
                      <tr>
                        <th scope="col" className="px-4 py-3">
                          Patient
                        </th>
                        <th scope="col" className="px-4 py-3">
                          Record ID
                        </th>
                        <th scope="col" className="px-4 py-3">
                          Requested At
                        </th>
                        <th scope="col" className="px-4 py-3">
                          Status
                        </th>
                        <th scope="col" className="px-4 py-3">
                          Action
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {stats.recentRequests.map((request: any) => (
                        <tr key={request.id} className="border-b">
                          <td className="px-4 py-3">{request.patient_name}</td>
                          <td className="px-4 py-3">{request.record_id}</td>
                          <td className="px-4 py-3">{new Date(request.requested_at).toLocaleDateString()}</td>
                          <td className="px-4 py-3">
                            <span
                              className={`px-2 py-1 rounded-full text-xs ${
                                request.status === "pending"
                                  ? "bg-amber-100 text-amber-800"
                                  : request.status === "approved"
                                    ? "bg-green-100 text-green-800"
                                    : request.status === "rejected"
                                      ? "bg-red-100 text-red-800"
                                      : "bg-gray-100 text-gray-800"
                              }`}
                            >
                              {request.status.charAt(0).toUpperCase() + request.status.slice(1)}
                            </span>
                          </td>
                          <td className="px-4 py-3">
                            <Link href={`/dashboard/admin/requests`}>
                              <Button variant="outline" size="sm">
                                View
                              </Button>
                            </Link>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <p className="text-muted-foreground">No requests found</p>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
