import { requireAuth } from "@/lib/auth"
import { DashboardHeader } from "@/components/dashboard-header"
import { CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import Link from "next/link"
import { FileText, Plus, Search } from "lucide-react"
import { GradientCard } from "@/components/ui/gradient-card"

const navigation = [
  { name: "Dashboard", href: "/dashboard/doctor" },
  { name: "Patients", href: "/dashboard/doctor/patients" },
  { name: "Records", href: "/dashboard/doctor/records" },
]

export default async function RecordsPage() {
  const user = await requireAuth(["doctor"])

  // This is a placeholder - in a real app, you would fetch records
  const records: any[] = []

  return (
    <div className="flex min-h-screen flex-col">
      <DashboardHeader user={user} navigation={navigation} />

      <main className="flex-1 container py-6">
        <div className="flex flex-col gap-6">
          <div className="flex items-center justify-between">
            <h1 className="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-green-600 to-teal-600">
              Medical Records
            </h1>
            <Link href="/dashboard/doctor/records/new">
              <Button className="bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800">
                <Plus className="mr-2 h-4 w-4" />
                Add Record
              </Button>
            </Link>
          </div>

          <div className="flex items-center gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input type="search" placeholder="Search records..." className="w-full bg-background pl-8" />
            </div>
          </div>

          <GradientCard gradient="green">
            <CardHeader>
              <CardTitle>All Records</CardTitle>
            </CardHeader>
            <CardContent>
              {records.length > 0 ? (
                <div className="space-y-4">
                  {records.map((record: any) => (
                    <div key={record.id} className="flex items-center justify-between border-b pb-4">
                      <div className="flex items-center gap-4">
                        <div className="flex h-12 w-12 items-center justify-center rounded-full bg-green-100 dark:bg-green-900/30">
                          <FileText className="h-6 w-6 text-green-600" />
                        </div>
                        <div>
                          <p className="font-medium">{record.description}</p>
                          <p className="text-sm text-muted-foreground">
                            Patient: {record.patient_name} • Added on {new Date(record.created_at).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Link href={`/dashboard/doctor/records/${record.id}`}>
                          <Button variant="outline" size="sm">
                            View
                          </Button>
                        </Link>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-12 text-center">
                  <FileText className="h-12 w-12 text-muted-foreground mb-4" />
                  <h3 className="text-lg font-medium">No records found</h3>
                  <p className="text-sm text-muted-foreground mt-1">Add a new medical record to get started.</p>
                  <Link href="/dashboard/doctor/records/new" className="mt-4">
                    <Button className="bg-green-600 hover:bg-green-700">
                      <Plus className="mr-2 h-4 w-4" />
                      Add Record
                    </Button>
                  </Link>
                </div>
              )}
            </CardContent>
          </GradientCard>
        </div>
      </main>
    </div>
  )
}
