import { requireAuth } from "@/lib/auth"
import { DashboardHeader } from "@/components/dashboard-header"
import { CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { FileText, UserRound, Plus } from "lucide-react"
import { getAllPatients } from "@/lib/db"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { StatCard } from "@/components/ui/stat-card"
import { GradientCard } from "@/components/ui/gradient-card"

const navigation = [
  { name: "Dashboard", href: "/dashboard/doctor" },
  { name: "Patients", href: "/dashboard/doctor/patients" },
  { name: "Records", href: "/dashboard/doctor/records" },
]

export default async function DoctorDashboard() {
  const user = await requireAuth(["doctor"])
  const patients = await getAllPatients()

  return (
    <div className="flex min-h-screen flex-col">
      <DashboardHeader user={user} navigation={navigation} />

      <main className="flex-1 container py-6">
        <div className="flex flex-col gap-6">
          <div className="flex items-center justify-between">
            <h1 className="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-green-600 to-teal-600">
              Doctor Dashboard
            </h1>
            <div className="flex gap-2">
              <Link href="/dashboard/doctor/patients/new">
                <Button className="bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800">
                  <Plus className="mr-2 h-4 w-4" />
                  Add Patient
                </Button>
              </Link>
              <Link href="/dashboard/doctor/records/new">
                <Button variant="outline">
                  <Plus className="mr-2 h-4 w-4" />
                  Add Record
                </Button>
              </Link>
            </div>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <StatCard
              title="Total Patients"
              value={patients.length}
              description="Patients in the system"
              icon={UserRound}
              iconClassName="bg-green-100 dark:bg-green-900/30"
            />

            <GradientCard gradient="green" className="flex items-center p-6">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-green-100 dark:bg-green-900/30 mr-4">
                <FileText className="h-6 w-6 text-green-600" />
              </div>
              <div>
                <p className="font-medium">{user.name}</p>
                <p className="text-sm text-muted-foreground">Doctor ID: {user.id}</p>
                <Link href="/dashboard/doctor/profile" className="mt-2 inline-block">
                  <Button variant="link" className="p-0 h-auto text-green-600">
                    View Profile
                  </Button>
                </Link>
              </div>
            </GradientCard>
          </div>

          <Tabs defaultValue="patients" className="w-full">
            <TabsList className="mb-2">
              <TabsTrigger value="patients">Recent Patients</TabsTrigger>
              <TabsTrigger value="records">Recent Records</TabsTrigger>
            </TabsList>
            <TabsContent value="patients" className="space-y-4">
              <GradientCard gradient="green">
                <CardHeader>
                  <CardTitle>Patients</CardTitle>
                  <CardDescription>Recently added patients in the system.</CardDescription>
                </CardHeader>
                <CardContent>
                  {patients.length > 0 ? (
                    <div className="space-y-4">
                      {patients.slice(0, 5).map((patient: any) => (
                        <div key={patient.id} className="flex items-center justify-between">
                          <div>
                            <p className="font-medium">{patient.name}</p>
                            <p className="text-sm text-muted-foreground">
                              {patient.age ? `${patient.age} years` : "Age not specified"} •
                              {patient.blood_group ? ` ${patient.blood_group}` : " Blood group not specified"}
                            </p>
                          </div>
                          <div className="flex gap-2">
                            <Link href={`/dashboard/doctor/patients/${patient.id}`}>
                              <Button variant="outline" size="sm">
                                View
                              </Button>
                            </Link>
                            <Link href={`/dashboard/doctor/records/new?patient=${patient.id}`}>
                              <Button size="sm" className="bg-green-600 hover:bg-green-700">
                                Add Record
                              </Button>
                            </Link>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-muted-foreground">No patients found.</p>
                  )}

                  <div className="mt-4 flex justify-end">
                    <Link href="/dashboard/doctor/patients">
                      <Button variant="outline">View All Patients</Button>
                    </Link>
                  </div>
                </CardContent>
              </GradientCard>
            </TabsContent>

            <TabsContent value="records" className="space-y-4">
              <GradientCard gradient="blue">
                <CardHeader>
                  <CardTitle>Medical Records</CardTitle>
                  <CardDescription>Recently added medical records.</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">Records will be displayed here.</p>
                  <div className="mt-4 flex justify-end">
                    <Link href="/dashboard/doctor/records">
                      <Button variant="outline">View All Records</Button>
                    </Link>
                  </div>
                </CardContent>
              </GradientCard>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}
