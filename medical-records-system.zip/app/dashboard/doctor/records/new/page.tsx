import { requireAuth } from "@/lib/auth"
import { DashboardHeader } from "@/components/dashboard-header"
import { getAllPatients, getUserById } from "@/lib/db"
import { RecordForm } from "@/components/record-form"

const navigation = [
  { name: "Dashboard", href: "/dashboard/doctor" },
  { name: "Patients", href: "/dashboard/doctor/patients" },
  { name: "Records", href: "/dashboard/doctor/records" },
]

export default async function NewRecordPage({ searchParams }: { searchParams: Promise<{ [key: string]: string | undefined }> }) {
  const user = await requireAuth(["doctor"])
  const patients = await getAllPatients()
  // Properly await searchParams - required in Next.js 15
  const resolvedSearchParams = await searchParams
  const selectedPatientId = resolvedSearchParams?.patient || ""

  // Get patient details if ID is provided
  let selectedPatient = null
  if (selectedPatientId) {
    selectedPatient = await getUserById(selectedPatientId)
  }

  return (
    <div className="flex min-h-screen flex-col">
      <DashboardHeader user={user} navigation={navigation} />

      <main className="flex-1 container py-6">
        <div className="flex flex-col gap-6">
          <h1 className="text-3xl font-bold">Add New Medical Record</h1>

          {selectedPatient ? (
            <RecordForm patientId={selectedPatient.id} patientName={selectedPatient.name} createdBy={user.id} />
          ) : (
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h2 className="text-xl font-semibold mb-4">Select a Patient</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {patients.map((patient: any) => (
                  <a
                    key={patient.id}
                    href={`/dashboard/doctor/records/new?patient=${patient.id}`}
                    className="block p-4 border rounded-md hover:bg-gray-50 transition-colors"
                  >
                    <h3 className="font-medium">{patient.name}</h3>
                    <p className="text-sm text-gray-500">ID: {patient.id}</p>
                    {patient.age && patient.sex && (
                      <p className="text-sm text-gray-500">
                        {patient.age} years, {patient.sex}
                      </p>
                    )}
                  </a>
                ))}
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  )
}
