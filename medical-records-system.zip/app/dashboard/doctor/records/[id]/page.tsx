import { requireAuth } from "@/lib/auth"
import { getMedicalRecord, getUserById } from "@/lib/db"
import { DashboardHeader } from "@/components/dashboard-header"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { DeleteRecordButton } from "@/components/delete-record-button"
import { ChevronLeft, FileText, Download } from "lucide-react"
import Link from "next/link"
import { notFound } from "next/navigation"

const navigation = [
  { name: "Dashboard", href: "/dashboard/doctor" },
  { name: "Patients", href: "/dashboard/doctor/patients" },
  { name: "Records", href: "/dashboard/doctor/records" },
]

export default async function RecordDetailsPage({ params }: { params: Promise<{ id: string }> }) {
  const user = await requireAuth(["doctor"])
  const { id: recordId } = await params

  const record = await getMedicalRecord(recordId)

  if (!record) {
    return notFound()
  }

  // Get patient information
  const patient = await getUserById(record.patient_id)

  return (
    <div className="flex min-h-screen flex-col">
      <DashboardHeader user={user} navigation={navigation} />

      <main className="flex-1 container py-6">
        <div className="flex flex-col gap-6">
          <div className="flex items-center gap-2">
            <Link href="/dashboard/doctor/records">
              <Button variant="outline" size="sm">
                <ChevronLeft className="mr-2 h-4 w-4" />
                Back to Records
              </Button>
            </Link>
            <h1 className="text-3xl font-bold">Record Details</h1>
          </div>

          <Card className="shadow-lg border-t-4 border-t-primary">
            <CardHeader className="bg-muted/50">
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-2xl font-bold text-primary">Medical Record Details</CardTitle>
                  <p className="text-sm text-muted-foreground">View complete information about this medical record</p>
                </div>
                <FileText className="h-10 w-10 text-primary opacity-80" />
              </div>
            </CardHeader>
            <CardContent className="pt-6">
              <div className="grid gap-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground">Record ID</h3>
                    <p className="mt-1 text-base font-medium">{record.id}</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground">Patient</h3>
                    <p className="mt-1 text-base font-medium">
                      {patient ? patient.name : "Unknown"} ({record.patient_id})
                    </p>
                  </div>
                </div>

                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Description</h3>
                  <p className="mt-1 text-base">{record.description}</p>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground">Created By</h3>
                    <p className="mt-1 text-base">{record.created_by}</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground">Created At</h3>
                    <p className="mt-1 text-base">{new Date(record.created_at).toLocaleDateString()}</p>
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground">File Name</h3>
                    <p className="mt-1 text-base">{record.file_name || "N/A"}</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground">File Type</h3>
                    <p className="mt-1 text-base">{record.file_type || "N/A"}</p>
                  </div>
                </div>

                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Record Hash</h3>
                  <p className="mt-1 text-base font-mono text-xs break-all">{record.hash}</p>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between bg-muted/30 py-4">
              <Link href="/dashboard/doctor/records">
                <Button variant="outline" className="border-2 hover:bg-muted bg-transparent">
                  Back to Records
                </Button>
              </Link>
              <div className="flex gap-3">
                <DeleteRecordButton recordId={record.id} redirectPath="/dashboard/doctor" />
                <Link href={`/api/records/download?recordId=${record.id}`} target="_blank" rel="noopener noreferrer">
                  <Button className="bg-primary hover:bg-primary/90">
                    <Download className="mr-2 h-4 w-4" />
                    Download Record
                  </Button>
                </Link>
              </div>
            </CardFooter>
          </Card>
        </div>
      </main>
    </div>
  )
}
