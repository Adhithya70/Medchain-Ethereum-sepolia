import { requireAuth } from "@/lib/auth"
import { DashboardHeader } from "@/components/dashboard-header"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { Plus, FileText, ExternalLink } from "lucide-react"
import { getAllMedicalRecordsByCreator } from "@/lib/db"
import { formatDate } from "@/lib/utils"
import { BlockchainTransactionBadge } from "@/components/blockchain-transaction-badge"

const navigation = [
  { name: "Dashboard", href: "/dashboard/doctor" },
  { name: "Patients", href: "/dashboard/doctor/patients" },
  { name: "Records", href: "/dashboard/doctor/records" },
]

export default async function DoctorRecordsPage() {
  const user = await requireAuth(["doctor"])
  const records = await getAllMedicalRecordsByCreator(user.id)

  return (
    <div className="flex min-h-screen flex-col">
      <DashboardHeader user={user} navigation={navigation} />

      <main className="flex-1 container py-6">
        <div className="flex flex-col gap-6">
          <div className="flex justify-between items-center">
            <h1 className="text-3xl font-bold">Medical Records</h1>
            <Link href="/dashboard/doctor/records/new">
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Add New Record
              </Button>
            </Link>
          </div>

          <div className="bg-white shadow-md rounded-lg overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm text-left">
                <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                  <tr>
                    <th className="px-6 py-3">ID</th>
                    <th className="px-6 py-3">Patient</th>
                    <th className="px-6 py-3">Description</th>
                    <th className="px-6 py-3">Created At</th>
                    <th className="px-6 py-3">Blockchain</th>
                    <th className="px-6 py-3">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {records.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="px-6 py-4 text-center">
                        No records found
                      </td>
                    </tr>
                  ) : (
                    records.map((record: any) => (
                      <tr key={record.id} className="border-b hover:bg-gray-50">
                        <td className="px-6 py-4 font-medium">{record.id.substring(0, 8)}...</td>
                        <td className="px-6 py-4">{record.patient_name}</td>
                        <td className="px-6 py-4">
                          <div className="flex items-center">
                            <FileText className="h-4 w-4 mr-2 text-gray-500" />
                            <span className="truncate max-w-[200px]">{record.description}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4">{formatDate(record.created_at)}</td>
                        <td className="px-6 py-4">
                          <BlockchainTransactionBadge txHash={record.blockchain_tx} />
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex space-x-2">
                            <Link href={`/dashboard/doctor/records/${record.id}`}>
                              <Button variant="outline" size="sm">
                                View
                              </Button>
                            </Link>
                            {record.blockchain_tx && (
                              <a
                                href={`https://sepolia.etherscan.io/tx/${record.blockchain_tx}`}
                                target="_blank"
                                rel="noopener noreferrer"
                              >
                                <Button variant="ghost" size="sm">
                                  <ExternalLink className="h-4 w-4" />
                                </Button>
                              </a>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
