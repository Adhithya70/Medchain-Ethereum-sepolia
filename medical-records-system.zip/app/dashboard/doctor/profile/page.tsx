import { requireAuth } from "@/lib/auth"
import { DashboardHeader } from "@/components/dashboard-header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { getUserById } from "@/lib/db"
import Link from "next/link"

const navigation = [
  { name: "Dashboard", href: "/dashboard/doctor" },
  { name: "Patients", href: "/dashboard/doctor/patients" },
  { name: "Records", href: "/dashboard/doctor/records" },
]

export default async function DoctorProfilePage() {
  const user = await requireAuth(["doctor"])

  // Get full doctor details
  const doctorDetails = await getUserById(user.id)

  return (
    <div className="flex min-h-screen flex-col">
      <DashboardHeader user={user} navigation={navigation} />

      <main className="flex-1 container py-6">
        <div className="flex flex-col gap-6">
          <div className="flex justify-between items-center">
            <h1 className="text-3xl font-bold">My Profile</h1>
            <Button asChild>
              <Link href="/dashboard/doctor/profile/edit">Edit Profile</Link>
            </Button>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Doctor Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-medium">Doctor ID</p>
                  <p className="text-sm text-muted-foreground">{doctorDetails.id}</p>
                </div>
                <div>
                  <p className="text-sm font-medium">Name</p>
                  <p className="text-sm text-muted-foreground">{doctorDetails.name}</p>
                </div>
                <div>
                  <p className="text-sm font-medium">Specialization</p>
                  <p className="text-sm text-muted-foreground">{doctorDetails.specialization || "Not specified"}</p>
                </div>
                <div>
                  <p className="text-sm font-medium">Experience</p>
                  <p className="text-sm text-muted-foreground">{doctorDetails.experience || "Not specified"}</p>
                </div>
                <div>
                  <p className="text-sm font-medium">University</p>
                  <p className="text-sm text-muted-foreground">{doctorDetails.university || "Not specified"}</p>
                </div>
                <div>
                  <p className="text-sm font-medium">Graduation Year</p>
                  <p className="text-sm text-muted-foreground">{doctorDetails.graduation_year || "Not specified"}</p>
                </div>
                <div>
                  <p className="text-sm font-medium">Medical College</p>
                  <p className="text-sm text-muted-foreground">{doctorDetails.college || "Not specified"}</p>
                </div>
                <div>
                  <p className="text-sm font-medium">Joining Date</p>
                  <p className="text-sm text-muted-foreground">
                    {doctorDetails.joining_date
                      ? new Date(doctorDetails.joining_date).toLocaleDateString()
                      : "Not specified"}
                  </p>
                </div>
              </div>
              {doctorDetails.remarks && (
                <div>
                  <p className="text-sm font-medium">Additional Remarks</p>
                  <p className="text-sm text-muted-foreground">{doctorDetails.remarks}</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
