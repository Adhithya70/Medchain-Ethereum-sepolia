import { requireAuth } from "@/lib/auth"
import { getUserById } from "@/lib/db"
import { DashboardHeader } from "@/components/dashboard-header"
import { EditDoctorProfileForm } from "@/components/edit-doctor-profile-form"

const navigation = [
  { name: "Dashboard", href: "/dashboard/doctor" },
  { name: "Patients", href: "/dashboard/doctor/patients" },
  { name: "Records", href: "/dashboard/doctor/records" },
]

export default async function EditDoctorProfilePage() {
  const user = await requireAuth(["doctor"])

  // Get full doctor details
  const doctorDetails = await getUserById(user.id)

  return (
    <div className="flex min-h-screen flex-col">
      <DashboardHeader user={user} navigation={navigation} />

      <main className="flex-1 container py-6">
        <div className="flex flex-col gap-6">
          <h1 className="text-3xl font-bold">Edit Profile</h1>

          <EditDoctorProfileForm doctor={doctorDetails} />
        </div>
      </main>
    </div>
  )
}
