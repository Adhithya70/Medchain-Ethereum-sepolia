import { requireAuth } from "@/lib/auth"
import { DashboardHeader } from "@/components/dashboard-header"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { ChevronLeft } from "lucide-react"
import { getUserById } from "@/lib/db"
import { notFound } from "next/navigation"
import { EditPatientByDoctorForm } from "@/components/edit-patient-by-doctor-form"

const navigation = [
  { name: "Dashboard", href: "/dashboard/doctor" },
  { name: "Patients", href: "/dashboard/doctor/patients" },
  { name: "Records", href: "/dashboard/doctor/records" },
]

export default async function EditPatientPage({ params }: { params: Promise<{ id: string }> }) {
  const user = await requireAuth(["doctor"])
  const { id: patientId } = await params

  const patient = await getUserById(patientId)

  if (!patient || patient.role !== "patient") {
    return notFound()
  }

  return (
    <div className="flex min-h-screen flex-col">
      <DashboardHeader user={user} navigation={navigation} />

      <main className="flex-1 container py-6">
        <div className="flex flex-col gap-6">
          <div className="flex items-center gap-2">
            <Link href={`/dashboard/doctor/patients/${patientId}`}>
              <Button variant="outline" size="sm">
                <ChevronLeft className="mr-2 h-4 w-4" />
                Back to Patient Details
              </Button>
            </Link>
            <h1 className="text-3xl font-bold">Edit Patient</h1>
          </div>

          <EditPatientByDoctorForm patient={patient} doctorId={user.id} />
        </div>
      </main>
    </div>
  )
}
