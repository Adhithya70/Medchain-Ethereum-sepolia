-- ============================================
-- COMPLETE MYSQL DATABASE SETUP SCRIPT
-- Medical Records System with Blockchain Audit Trail
-- ============================================
-- Database: medical_record
-- User: root
-- Password: Adhi@2002
-- Host: localhost:3306
-- ============================================

-- Step 1: Create Database
-- ============================================
CREATE DATABASE IF NOT EXISTS medical_record;
USE medical_record;

-- Step 2: Create Users Table
-- ============================================
CREATE TABLE IF NOT EXISTS users (
  id VARCHAR(36) PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  password VARCHAR(255) NOT NULL,
  role ENUM('doctor', 'patient', 'admin') NOT NULL,
  
  -- Doctor-specific fields
  specialization VARCHAR(255),
  university VARCHAR(255),
  graduation_year INT,
  experience INT,
  
  -- Patient-specific fields
  college VARCHAR(255),
  age INT,
  sex VARCHAR(10),
  blood_group VARCHAR(5),
  
  -- Common fields
  remarks TEXT,
  joining_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  KEY idx_role (role),
  KEY idx_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Step 3: Create Medical Records Table
-- ============================================
CREATE TABLE IF NOT EXISTS medical_records (
  id VARCHAR(36) PRIMARY KEY,
  patient_id VARCHAR(36) NOT NULL,
  description TEXT,
  file_name VARCHAR(255),
  file_type VARCHAR(100),
  file_size BIGINT,
  file_path VARCHAR(500),
  file_data LONGBLOB,
  hash VARCHAR(255) NOT NULL UNIQUE,
  blockchain_tx VARCHAR(255),
  created_by VARCHAR(36) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (patient_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (created_by) REFERENCES users(id),
  
  KEY idx_patient (patient_id),
  KEY idx_created_by (created_by),
  KEY idx_hash (hash),
  KEY idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Step 4: Create Download Requests Table
-- ============================================
CREATE TABLE IF NOT EXISTS download_requests (
  id VARCHAR(36) PRIMARY KEY,
  patient_id VARCHAR(36) NOT NULL,
  record_id VARCHAR(36) NOT NULL,
  record_hash VARCHAR(255),
  record_description TEXT,
  status ENUM('pending', 'approved', 'rejected', 'downloaded') DEFAULT 'pending',
  blockchain_tx VARCHAR(255),
  requested_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  approved_at TIMESTAMP NULL,
  rejected_at TIMESTAMP NULL,
  downloaded_at TIMESTAMP NULL,
  
  FOREIGN KEY (patient_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (record_id) REFERENCES medical_records(id),
  
  KEY idx_patient (patient_id),
  KEY idx_record (record_id),
  KEY idx_status (status),
  KEY idx_requested_at (requested_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Step 5: Create Download History Table
-- ============================================
CREATE TABLE IF NOT EXISTS download_history (
  id VARCHAR(36) PRIMARY KEY,
  patient_id VARCHAR(36) NOT NULL,
  record_id VARCHAR(36) NOT NULL,
  record_hash VARCHAR(255),
  record_description TEXT,
  blockchain_tx VARCHAR(255),
  downloaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (patient_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (record_id) REFERENCES medical_records(id),
  
  KEY idx_patient (patient_id),
  KEY idx_record (record_id),
  KEY idx_downloaded_at (downloaded_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Step 6: Create Blockchain Audit Log Table (Immutable)
-- ============================================
CREATE TABLE IF NOT EXISTS blockchain_audit_log (
  id VARCHAR(36) PRIMARY KEY,
  action_type ENUM(
    'RECORD_CREATED',
    'RECORD_DELETED',
    'DOWNLOAD_REQUESTED',
    'DOWNLOAD_APPROVED',
    'DOWNLOAD_REJECTED',
    'DOWNLOAD_COMPLETED',
    'STATUS_CHANGED'
  ) NOT NULL,
  record_id VARCHAR(36),
  request_id VARCHAR(36),
  user_id VARCHAR(36) NOT NULL,
  user_name VARCHAR(255) NOT NULL,
  user_role ENUM('doctor', 'patient', 'admin') NOT NULL,
  actor_user_id VARCHAR(36),
  actor_user_name VARCHAR(255),
  actor_user_role ENUM('doctor', 'patient', 'admin'),
  patient_id VARCHAR(36),
  description TEXT,
  details JSON,
  blockchain_tx VARCHAR(255),
  blockchain_block_number INT,
  timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  immutable BOOLEAN DEFAULT TRUE,
  
  INDEX idx_record_id (record_id),
  INDEX idx_request_id (request_id),
  INDEX idx_user_id (user_id),
  INDEX idx_action_type (action_type),
  INDEX idx_timestamp (timestamp),
  INDEX idx_blockchain_tx (blockchain_tx),
  INDEX idx_immutable_records (immutable, timestamp),
  
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (actor_user_id) REFERENCES users(id),
  FOREIGN KEY (patient_id) REFERENCES users(id),
  FOREIGN KEY (record_id) REFERENCES medical_records(id) ON DELETE SET NULL,
  FOREIGN KEY (request_id) REFERENCES download_requests(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Step 7: Insert Admin User
-- ============================================
INSERT INTO users (id, name, password, role, remarks, joining_date) 
VALUES (
  'Admin',
  'Admin',
  'admin123',
  'admin',
  'System Administrator',
  NOW()
);

-- Step 8: Verification Queries
-- ============================================
-- Verify all tables were created
SELECT 'Database setup completed successfully!' AS status;
SELECT COUNT(*) as total_tables FROM information_schema.TABLES WHERE TABLE_SCHEMA = 'medical_record';
SELECT id, name, role FROM users WHERE role = 'admin';

-- ============================================
-- ADMIN LOGIN CREDENTIALS
-- ============================================
-- User ID: Admin
-- Password: admin123
-- Role: admin
-- Access URL: http://localhost:3000/login/admin
-- ============================================
