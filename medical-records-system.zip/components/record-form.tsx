"use client"

import type React from "react"

import { useState, useRef } from "react"
import { useRouter } from "next/navigation"
import { useToast } from "@/hooks/use-toast"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { useWallet } from "@/contexts/wallet-context"
import { logRecordAdded } from "@/lib/blockchain/contract"
import { Loader2 } from "lucide-react"

interface RecordFormProps {
  patientId: string
  patientName: string
  createdBy: string
}

export function RecordForm({ patientId, patientName, createdBy }: RecordFormProps) {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isBlockchainProcessing, setIsBlockchainProcessing] = useState(false)
  const [description, setDescription] = useState("")
  const [file, setFile] = useState<File | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const { toast } = useToast()
  const router = useRouter()
  const { isConnected, provider } = useWallet()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!description || !file) {
      toast({
        title: "Missing Fields",
        description: "Please provide a description and upload a file",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    try {
      // Create form data
      const formData = new FormData()
      formData.append("patient_id", patientId)
      formData.append("description", description)
      formData.append("created_by", createdBy)
      formData.append("file", file)

      // Submit to API
      const response = await fetch("/api/records/create", {
        method: "POST",
        body: formData,
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.message || "Failed to create record")
      }

      toast({
        title: "Record Created",
        description: "Medical record has been saved to the database",
      })

      // If connected to wallet, try to log the transaction on the blockchain from the client side
      if (isConnected && provider && data.record) {
        try {
          setIsBlockchainProcessing(true)
          console.log("Using connected wallet for blockchain transaction")

          const blockchainResult = await logRecordAdded(
            data.record.id,
            data.record.hash || "",
            patientId,
            createdBy,
            provider,
          )

          if (blockchainResult.success && blockchainResult.txHash) {
            // Update the record with the transaction hash
            await fetch("/api/records/update-tx", {
              method: "POST",
              headers: {
                "Content-Type": "application/json",
              },
              body: JSON.stringify({
                recordId: data.record.id,
                txHash: blockchainResult.txHash,
              }),
            })

            toast({
              title: "Blockchain Transaction Successful",
              description: `Transaction hash: ${blockchainResult.txHash.substring(0, 10)}...`,
            })
          }
        } catch (blockchainError) {
          console.error("Client-side blockchain error:", blockchainError)
          toast({
            title: "Blockchain Transaction Failed",
            description: "Record was saved but blockchain transaction failed",
            variant: "destructive",
          })
        } finally {
          setIsBlockchainProcessing(false)
        }
      }

      // Redirect based on role after a short delay
      setTimeout(() => {
        if (createdBy.startsWith("admin")) {
          router.push("/dashboard/admin/records")
        } else {
          router.push("/dashboard/doctor/records")
        }
        router.refresh()
      }, 1000)
    } catch (error: any) {
      console.error("Error creating record:", error)
      toast({
        title: "Error",
        description: error.message || "Failed to create medical record",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0])
    }
  }

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle>Add Medical Record</CardTitle>
        <CardDescription>
          Create a new medical record for patient: <strong>{patientName}</strong>
        </CardDescription>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              placeholder="Enter record description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              required
              className="min-h-32"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="file">Upload File</Label>
            <Input ref={fileInputRef} id="file" type="file" onChange={handleFileChange} required />
            <p className="text-sm text-gray-500">Upload medical documents, images, or other relevant files</p>
          </div>

          {isConnected && (
            <div className="bg-green-50 p-3 rounded-md border border-green-200">
              <p className="text-sm text-green-800">
                You are connected with your wallet. Transaction fees will be paid from your wallet.
              </p>
            </div>
          )}

          {!isConnected && (
            <div className="bg-yellow-50 p-3 rounded-md border border-yellow-200">
              <p className="text-sm text-yellow-800">
                No wallet connected. Transaction fees will be paid from the system wallet.
              </p>
            </div>
          )}
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button
            type="button"
            variant="outline"
            onClick={() => router.back()}
            disabled={isSubmitting || isBlockchainProcessing}
          >
            Cancel
          </Button>
          <Button type="submit" disabled={isSubmitting || isBlockchainProcessing}>
            {isSubmitting ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Saving to Database...
              </>
            ) : isBlockchainProcessing ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Recording on Blockchain...
              </>
            ) : (
              "Create Record"
            )}
          </Button>
        </CardFooter>
      </form>
    </Card>
  )
}
