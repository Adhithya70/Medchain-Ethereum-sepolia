"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import Link from "next/link"
import { useToast } from "@/hooks/use-toast"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export function DoctorForm() {
  const router = useRouter()
  const { toast } = useToast()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [bloodGroup, setBloodGroup] = useState("")
  const [sex, setSex] = useState("")

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setIsSubmitting(true)

    try {
      const formData = new FormData(event.currentTarget)
      formData.append("blood_group", bloodGroup)
      formData.append("sex", sex)

      const response = await fetch("/api/doctors/create", {
        method: "POST",
        body: formData,
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.message || "Failed to create doctor")
      }

      toast({
        variant: "success",
        title: "Success!",
        description: "Doctor has been successfully created.",
      })

      // Redirect after a short delay
      setTimeout(() => {
        router.push("/dashboard/admin/doctors")
        router.refresh()
      }, 1000)
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "An error occurred while creating the doctor",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <Card className="shadow-lg border-t-4 border-t-primary">
      <form onSubmit={handleSubmit}>
        <CardHeader className="bg-muted/50">
          <CardTitle className="text-2xl font-bold text-primary">Doctor Information</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6 pt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="id" className="text-sm font-medium">
                Doctor ID
              </Label>
              <Input
                id="id"
                name="id"
                placeholder="Enter doctor ID"
                required
                className="border-2 focus-visible:ring-primary"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="name" className="text-sm font-medium">
                Full Name
              </Label>
              <Input
                id="name"
                name="name"
                placeholder="Enter full name"
                required
                className="border-2 focus-visible:ring-primary"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="password" className="text-sm font-medium">
              Password
            </Label>
            <Input
              id="password"
              name="password"
              type="password"
              placeholder="Enter password"
              required
              className="border-2 focus-visible:ring-primary"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-2">
              <Label htmlFor="age" className="text-sm font-medium">
                Age
              </Label>
              <Input
                id="age"
                name="age"
                type="number"
                placeholder="Enter age"
                className="border-2 focus-visible:ring-primary"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="sex" className="text-sm font-medium">
                Sex
              </Label>
              <Select value={sex} onValueChange={setSex}>
                <SelectTrigger className="border-2 focus-visible:ring-primary">
                  <SelectValue placeholder="Select sex" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="male">Male</SelectItem>
                  <SelectItem value="female">Female</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="blood_group" className="text-sm font-medium">
                Blood Group
              </Label>
              <Select value={bloodGroup} onValueChange={setBloodGroup}>
                <SelectTrigger className="border-2 focus-visible:ring-primary">
                  <SelectValue placeholder="Select blood group" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="A+">A+</SelectItem>
                  <SelectItem value="A-">A-</SelectItem>
                  <SelectItem value="B+">B+</SelectItem>
                  <SelectItem value="B-">B-</SelectItem>
                  <SelectItem value="AB+">AB+</SelectItem>
                  <SelectItem value="AB-">AB-</SelectItem>
                  <SelectItem value="O+">O+</SelectItem>
                  <SelectItem value="O-">O-</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="specialization" className="text-sm font-medium">
                Specialization
              </Label>
              <Input
                id="specialization"
                name="specialization"
                placeholder="E.g., Cardiology"
                className="border-2 focus-visible:ring-primary"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="experience" className="text-sm font-medium">
                Experience (years)
              </Label>
              <Input
                id="experience"
                name="experience"
                placeholder="E.g., 5 years"
                className="border-2 focus-visible:ring-primary"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="university" className="text-sm font-medium">
                University
              </Label>
              <Input
                id="university"
                name="university"
                placeholder="Medical university name"
                className="border-2 focus-visible:ring-primary"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="graduation_year" className="text-sm font-medium">
                Graduation Year
              </Label>
              <Input
                id="graduation_year"
                name="graduation_year"
                placeholder="E.g., 2015"
                className="border-2 focus-visible:ring-primary"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="college" className="text-sm font-medium">
              Medical College
            </Label>
            <Input
              id="college"
              name="college"
              placeholder="Medical college name"
              className="border-2 focus-visible:ring-primary"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="remarks" className="text-sm font-medium">
              Additional Remarks
            </Label>
            <Textarea
              id="remarks"
              name="remarks"
              placeholder="Any additional information"
              className="min-h-[100px] border-2 focus-visible:ring-primary"
            />
          </div>
        </CardContent>
        <CardFooter className="flex justify-end gap-3 bg-muted/30 py-4">
          <Link href="/dashboard/admin/doctors">
            <Button variant="outline" type="button" className="border-2 hover:bg-muted">
              Cancel
            </Button>
          </Link>
          <Button type="submit" disabled={isSubmitting} className="bg-primary hover:bg-primary/90">
            {isSubmitting ? "Creating..." : "Create Doctor"}
          </Button>
        </CardFooter>
      </form>
    </Card>
  )
}
