"use client"
import { Badge } from "@/components/ui/badge"
import { CheckCircle2, Loader2 } from "lucide-react"

interface BlockchainTransactionBadgeProps {
  loading?: boolean
}

export function BlockchainTransactionBadge({ loading = false }: BlockchainTransactionBadgeProps) {
  if (loading) {
    return (
      <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200 flex items-center gap-1">
        <Loader2 className="h-3 w-3 animate-spin" />
        <span>Recording on blockchain...</span>
      </Badge>
    )
  }

  return (
    <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200 flex items-center gap-1">
      <CheckCircle2 className="h-3 w-3" />
      <span>Recorded on blockchain</span>
    </Badge>
  )
}
