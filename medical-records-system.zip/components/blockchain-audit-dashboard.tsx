"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Select } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { formatDistanceToNow } from "date-fns"

interface AuditLog {
  id: string
  action_type: string
  record_id?: string
  request_id?: string
  user_id: string
  user_name: string
  user_role: string
  actor_user_id?: string
  actor_user_name?: string
  actor_user_role?: string
  patient_id?: string
  description?: string
  details?: Record<string, any>
  blockchain_tx?: string
  blockchain_block_number?: number
  timestamp: string
}

const actionTypeColors: Record<string, string> = {
  RECORD_CREATED: "bg-green-100 text-green-800",
  RECORD_DELETED: "bg-red-100 text-red-800",
  DOWNLOAD_REQUESTED: "bg-blue-100 text-blue-800",
  DOWNLOAD_APPROVED: "bg-emerald-100 text-emerald-800",
  DOWNLOAD_REJECTED: "bg-orange-100 text-orange-800",
  DOWNLOAD_COMPLETED: "bg-purple-100 text-purple-800",
  STATUS_CHANGED: "bg-yellow-100 text-yellow-800",
}

const actionTypeLabels: Record<string, string> = {
  RECORD_CREATED: "Record Created",
  RECORD_DELETED: "Record Deleted",
  DOWNLOAD_REQUESTED: "Download Requested",
  DOWNLOAD_APPROVED: "Download Approved",
  DOWNLOAD_REJECTED: "Download Rejected",
  DOWNLOAD_COMPLETED: "Download Completed",
  STATUS_CHANGED: "Status Changed",
}

export function BlockchainAuditDashboard() {
  const [logs, setLogs] = useState<AuditLog[]>([])
  const [loading, setLoading] = useState(true)
  const [actionFilter, setActionFilter] = useState<string>("")
  const [userFilter, setUserFilter] = useState<string>("")
  const [recordFilter, setRecordFilter] = useState<string>("")
  const [patientFilter, setPatientFilter] = useState<string>("")

  useEffect(() => {
    fetchAuditLogs()
  }, [actionFilter, userFilter, recordFilter, patientFilter])

  async function fetchAuditLogs() {
    setLoading(true)
    try {
      const params = new URLSearchParams()
      if (actionFilter) params.append("action_type", actionFilter)
      if (userFilter) params.append("user_id", userFilter)
      if (recordFilter) params.append("record_id", recordFilter)
      if (patientFilter) params.append("patient_id", patientFilter)
      params.append("limit", "100")

      const response = await fetch(`/api/audit/logs?${params.toString()}`)
      const data = await response.json()

      if (data.success) {
        setLogs(data.logs)
      }
    } catch (error) {
      console.error("Error fetching audit logs:", error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-col gap-4">
        <h2 className="text-2xl font-bold">Blockchain Transaction Audit Trail</h2>
        <p className="text-muted-foreground">
          Immutable record of all system transactions. These records remain permanent even if related records are deleted.
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Filters</CardTitle>
          <CardDescription>Search and filter blockchain transactions</CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col gap-4 md:flex-row md:flex-wrap">
          <div className="flex flex-col gap-2 flex-1 min-w-48">
            <label className="text-sm font-medium">Action Type</label>
            <select
              value={actionFilter}
              onChange={(e) => setActionFilter(e.target.value)}
              className="border rounded-md px-3 py-2 text-sm"
            >
              <option value="">All Actions</option>
              <option value="RECORD_CREATED">Record Created</option>
              <option value="RECORD_DELETED">Record Deleted</option>
              <option value="DOWNLOAD_REQUESTED">Download Requested</option>
              <option value="DOWNLOAD_APPROVED">Download Approved</option>
              <option value="DOWNLOAD_REJECTED">Download Rejected</option>
              <option value="DOWNLOAD_COMPLETED">Download Completed</option>
              <option value="STATUS_CHANGED">Status Changed</option>
            </select>
          </div>

          <div className="flex flex-col gap-2 flex-1 min-w-48">
            <label className="text-sm font-medium">Record ID</label>
            <Input
              placeholder="Filter by record ID"
              value={recordFilter}
              onChange={(e) => setRecordFilter(e.target.value)}
            />
          </div>

          <div className="flex flex-col gap-2 flex-1 min-w-48">
            <label className="text-sm font-medium">Patient ID</label>
            <Input
              placeholder="Filter by patient ID"
              value={patientFilter}
              onChange={(e) => setPatientFilter(e.target.value)}
            />
          </div>

          <div className="flex flex-col gap-2 flex-1 min-w-48">
            <label className="text-sm font-medium">User ID</label>
            <Input
              placeholder="Filter by user ID"
              value={userFilter}
              onChange={(e) => setUserFilter(e.target.value)}
            />
          </div>

          <div className="flex items-end">
            <Button
              variant="outline"
              onClick={() => {
                setActionFilter("")
                setUserFilter("")
                setRecordFilter("")
                setPatientFilter("")
              }}
            >
              Clear Filters
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Transaction History</CardTitle>
          <CardDescription>
            Total transactions: {logs.length}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex justify-center py-8">
              <p className="text-muted-foreground">Loading transactions...</p>
            </div>
          ) : logs.length === 0 ? (
            <div className="flex justify-center py-8">
              <p className="text-muted-foreground">No transactions found</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b">
                    <th className="text-left py-3 px-4 font-medium">Timestamp</th>
                    <th className="text-left py-3 px-4 font-medium">Action</th>
                    <th className="text-left py-3 px-4 font-medium">User</th>
                    <th className="text-left py-3 px-4 font-medium">Actor</th>
                    <th className="text-left py-3 px-4 font-medium">Record</th>
                    <th className="text-left py-3 px-4 font-medium">Patient</th>
                    <th className="text-left py-3 px-4 font-medium">Blockchain TX</th>
                  </tr>
                </thead>
                <tbody>
                  {logs.map((log) => (
                    <tr key={log.id} className="border-b hover:bg-muted/50">
                      <td className="py-3 px-4">
                        <span className="text-xs">
                          {formatDistanceToNow(new Date(log.timestamp), { addSuffix: true })}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <Badge className={actionTypeColors[log.action_type]}>
                          {actionTypeLabels[log.action_type]}
                        </Badge>
                      </td>
                      <td className="py-3 px-4">
                        <div className="text-xs">
                          <p className="font-medium">{log.user_name}</p>
                          <p className="text-muted-foreground">{log.user_role}</p>
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        {log.actor_user_name ? (
                          <div className="text-xs">
                            <p className="font-medium">{log.actor_user_name}</p>
                            <p className="text-muted-foreground">{log.actor_user_role}</p>
                          </div>
                        ) : (
                          <span className="text-muted-foreground text-xs">-</span>
                        )}
                      </td>
                      <td className="py-3 px-4">
                        <code className="text-xs bg-muted px-2 py-1 rounded">{log.record_id || "-"}</code>
                      </td>
                      <td className="py-3 px-4">
                        <code className="text-xs bg-muted px-2 py-1 rounded">{log.patient_id || "-"}</code>
                      </td>
                      <td className="py-3 px-4">
                        {log.blockchain_tx ? (
                          <a
                            href={`https://sepolia.etherscan.io/tx/${log.blockchain_tx}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-xs text-blue-600 hover:underline truncate max-w-24"
                          >
                            {log.blockchain_tx.slice(0, 10)}...
                          </a>
                        ) : (
                          <span className="text-muted-foreground text-xs">Pending</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
