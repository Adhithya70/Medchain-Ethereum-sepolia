import type React from "react"
import { cn } from "@/lib/utils"

interface GradientCardProps extends React.HTMLAttributes<HTMLDivElement> {
  children: React.ReactNode
  gradient?: "blue" | "green" | "purple" | "amber" | "rose"
}

export function GradientCard({ children, className, gradient = "blue", ...props }: GradientCardProps) {
  const gradientStyles = {
    blue: "bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-950/50 dark:to-blue-900/30 border-blue-200 dark:border-blue-800",
    green:
      "bg-gradient-to-br from-green-50 to-green-100 dark:from-green-950/50 dark:to-green-900/30 border-green-200 dark:border-green-800",
    purple:
      "bg-gradient-to-br from-purple-50 to-purple-100 dark:from-purple-950/50 dark:to-purple-900/30 border-purple-200 dark:border-purple-800",
    amber:
      "bg-gradient-to-br from-amber-50 to-amber-100 dark:from-amber-950/50 dark:to-amber-900/30 border-amber-200 dark:border-amber-800",
    rose: "bg-gradient-to-br from-rose-50 to-rose-100 dark:from-rose-950/50 dark:to-rose-900/30 border-rose-200 dark:border-rose-800",
  }

  return (
    <div
      className={cn("rounded-xl border shadow-sm transition-all hover:shadow-md", gradientStyles[gradient], className)}
      {...props}
    >
      {children}
    </div>
  )
}
