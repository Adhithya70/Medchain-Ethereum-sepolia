"use client"

import type React from "react"

import { useEffect, useRef } from "react"
import { cn } from "@/lib/utils"

interface AnimatedGradientBackgroundProps extends React.HTMLAttributes<HTMLDivElement> {
  children: React.ReactNode
}

export function AnimatedGradientBackground({ children, className, ...props }: AnimatedGradientBackgroundProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    let animationFrameId: number
    let width = (canvas.width = window.innerWidth)
    let height = (canvas.height = window.innerHeight)

    // Create gradient circles
    const circles = [
      { x: width * 0.3, y: height * 0.3, r: Math.max(width, height) * 0.3, color: "rgba(59, 130, 246, 0.15)" }, // Blue
      { x: width * 0.7, y: height * 0.7, r: Math.max(width, height) * 0.3, color: "rgba(16, 185, 129, 0.15)" }, // Green
      { x: width * 0.5, y: height * 0.2, r: Math.max(width, height) * 0.2, color: "rgba(168, 85, 247, 0.15)" }, // Purple
    ]

    const animate = () => {
      ctx.clearRect(0, 0, width, height)

      // Draw gradient circles
      circles.forEach((circle, i) => {
        const gradient = ctx.createRadialGradient(circle.x, circle.y, 0, circle.x, circle.y, circle.r)
        gradient.addColorStop(0, circle.color)
        gradient.addColorStop(1, "rgba(255, 255, 255, 0)")

        ctx.fillStyle = gradient
        ctx.beginPath()
        ctx.arc(circle.x, circle.y, circle.r, 0, Math.PI * 2)
        ctx.fill()

        // Slowly move circles
        circles[i].x += Math.sin(Date.now() * 0.0005 + i) * 0.5
        circles[i].y += Math.cos(Date.now() * 0.0005 + i) * 0.5
      })

      animationFrameId = requestAnimationFrame(animate)
    }

    animate()

    const handleResize = () => {
      width = canvas.width = window.innerWidth
      height = canvas.height = window.innerHeight

      // Update circle positions on resize
      circles[0] = { ...circles[0], x: width * 0.3, y: height * 0.3, r: Math.max(width, height) * 0.3 }
      circles[1] = { ...circles[1], x: width * 0.7, y: height * 0.7, r: Math.max(width, height) * 0.3 }
      circles[2] = { ...circles[2], x: width * 0.5, y: height * 0.2, r: Math.max(width, height) * 0.2 }
    }

    window.addEventListener("resize", handleResize)

    return () => {
      window.removeEventListener("resize", handleResize)
      cancelAnimationFrame(animationFrameId)
    }
  }, [])

  return (
    <div className={cn("relative overflow-hidden", className)} {...props}>
      <canvas ref={canvasRef} className="absolute inset-0 -z-10" style={{ filter: "blur(80px)" }} />
      {children}
    </div>
  )
}
