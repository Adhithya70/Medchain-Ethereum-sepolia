"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Download } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { useRouter } from "next/navigation"

interface DownloadRecordButtonProps {
  recordId: string
  requestId?: string
}

export function DownloadRecordButton({ recordId, requestId }: DownloadRecordButtonProps) {
  const [isDownloading, setIsDownloading] = useState(false)
  const { toast } = useToast()
  const router = useRouter()

  async function handleDownload() {
    if (!recordId) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Record ID is missing",
      })
      return
    }

    setIsDownloading(true)

    try {
      // If we have a requestId, mark the request as downloaded first
      if (requestId) {
        const statusResponse = await fetch("/api/requests/update-status", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            requestId,
            status: "downloaded",
          }),
        })

        if (!statusResponse.ok) {
          const error = await statusResponse.json()
          throw new Error(error.message || "Failed to update request status")
        }
      }

      // Open the download in a new tab
      window.open(`/api/records/download?recordId=${recordId}`, "_blank")

      toast({
        variant: "success",
        title: "Download Started",
        description: "Your medical record is being downloaded.",
      })

      // If this was a request download, redirect back to requests page after a short delay
      if (requestId) {
        setTimeout(() => {
          router.push("/dashboard/patient/requests")
          router.refresh()
        }, 1500)
      }
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "An error occurred while downloading the record",
      })
    } finally {
      setIsDownloading(false)
    }
  }

  return (
    <Button onClick={handleDownload} disabled={isDownloading}>
      <Download className="mr-2 h-4 w-4" />
      {isDownloading ? "Downloading..." : "Download Record"}
    </Button>
  )
}
