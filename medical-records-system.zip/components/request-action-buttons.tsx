"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { CheckCircle, XCircle } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { useRouter } from "next/navigation"

interface RequestActionButtonsProps {
  requestId: string
}

export function RequestActionButtons({ requestId }: RequestActionButtonsProps) {
  const [isProcessing, setIsProcessing] = useState(false)
  const [isBlockchainProcessing, setIsBlockchainProcessing] = useState(false)
  const { toast } = useToast()
  const router = useRouter()

  async function handleAction(action: "approve" | "reject") {
    setIsProcessing(true)
    setIsBlockchainProcessing(true)

    try {
      const response = await fetch("/api/requests/update-status", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          requestId,
          status: action === "approve" ? "approved" : "rejected",
        }),
      })

      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.message || `Failed to ${action} request`)
      }

      // Set blockchain processing to false after a delay to simulate blockchain confirmation
      setTimeout(() => setIsBlockchainProcessing(false), 2000)

      toast({
        variant: "success",
        title: "Success",
        description: `Request has been ${action === "approve" ? "approved" : "rejected"} and recorded on the blockchain.`,
      })

      // Refresh the page
      router.refresh()
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || `An error occurred while ${action}ing the request`,
      })
      setIsBlockchainProcessing(false)
    } finally {
      setIsProcessing(false)
    }
  }

  return (
    <div className="flex gap-2">
      <Button
        variant="outline"
        size="sm"
        className="text-green-500 border-green-500"
        onClick={() => handleAction("approve")}
        disabled={isProcessing}
      >
        <CheckCircle className="mr-2 h-4 w-4" />
        {isProcessing ? "Processing..." : "Approve"}
      </Button>
      <Button
        variant="outline"
        size="sm"
        className="text-red-500 border-red-500"
        onClick={() => handleAction("reject")}
        disabled={isProcessing}
      >
        <XCircle className="mr-2 h-4 w-4" />
        {isProcessing ? "Processing..." : "Reject"}
      </Button>
    </div>
  )
}
