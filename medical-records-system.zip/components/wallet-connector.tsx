"use client"

import { Button } from "@/components/ui/button"
import { useWallet } from "@/contexts/wallet-context"
import { Wallet, Loader2 } from "lucide-react"

export function WalletConnector() {
  const { account, connectWallet, disconnectWallet, isConnected, isConnecting, hasMetaMask } = useWallet()

  const shortenAddress = (address: string) => {
    return `${address.substring(0, 6)}...${address.substring(address.length - 4)}`
  }

  return (
    <div className="flex items-center">
      {hasMetaMask ? (
        isConnected ? (
          <div className="flex items-center gap-2">
            <div className="bg-green-100 text-green-800 text-xs font-medium px-2.5 py-0.5 rounded-full flex items-center">
              <span className="w-2 h-2 bg-green-500 rounded-full mr-1"></span>
              {shortenAddress(account!)}
            </div>
            <Button variant="outline" size="sm" onClick={disconnectWallet}>
              Disconnect
            </Button>
          </div>
        ) : (
          <Button
            variant="outline"
            size="sm"
            onClick={connectWallet}
            disabled={isConnecting}
            className="flex items-center gap-1"
          >
            {isConnecting ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin mr-1" />
                Connecting...
              </>
            ) : (
              <>
                <Wallet className="h-4 w-4 mr-1" />
                Connect Wallet
              </>
            )}
          </Button>
        )
      ) : (
        <div className="text-xs text-gray-500">MetaMask not installed</div>
      )}
    </div>
  )
}
