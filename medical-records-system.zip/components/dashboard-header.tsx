import Link from "next/link"
import type { User } from "@/lib/db"
import { ThemeToggle } from "@/components/theme-toggle"
import { Button } from "@/components/ui/button"
import { LogOut } from "lucide-react"
import { WalletConnector } from "@/components/wallet-connector"

interface DashboardHeaderProps {
  user: User
  navigation: { name: string; href: string }[]
}

export function DashboardHeader({ user, navigation }: DashboardHeaderProps) {
  return (
    <header className="bg-white shadow dark:bg-gray-800">
      <div className="mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 justify-between">
          <div className="flex">
            <div className="flex flex-shrink-0 items-center">
              <Link href="/" className="text-xl font-bold text-gray-900 dark:text-white">
                MedChain
              </Link>
            </div>
            <nav className="ml-6 flex space-x-4 sm:space-x-8">
              {navigation.map((item) => (
                <Link
                  key={item.name}
                  href={item.href}
                  className="inline-flex items-center border-b-2 border-transparent px-1 pt-1 text-sm font-medium text-gray-500 hover:border-gray-300 hover:text-gray-700 dark:text-gray-300 dark:hover:border-gray-600 dark:hover:text-white"
                >
                  {item.name}
                </Link>
              ))}
            </nav>
          </div>
          <div className="flex items-center space-x-4">
            <WalletConnector />
            <ThemeToggle />
            <div className="flex items-center space-x-2">
              <span className="text-sm font-medium text-gray-700 dark:text-gray-200">{user.name || user.username}</span>
              <form action="/api/auth/logout" method="post">
                <Button variant="ghost" size="icon" type="submit" title="Logout">
                  <LogOut className="h-5 w-5" />
                </Button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </header>
  )
}
