# Blockchain Audit Trail Feature Setup

This guide explains how to set up the immutable blockchain audit trail feature for tracking all system transactions.

## Overview

The blockchain audit trail feature creates an immutable record of all system transactions:
- Record creation and deletion
- Download requests and approvals
- Status changes and user actions
- Both users involved in each transaction

## Database Setup

The system uses the **medical_record** database with the following credentials:
- **User:** root
- **Password:** Adhi@2002
- **Host:** localhost:3306

### 1. Create the Audit Log Table

Run this SQL query to create the `blockchain_audit_log` table in the `medical_record` database:

```sql
CREATE TABLE IF NOT EXISTS blockchain_audit_log (
  id VARCHAR(36) PRIMARY KEY,
  action_type ENUM(
    'RECORD_CREATED',
    'RECORD_DELETED',
    'DOWNLOAD_REQUESTED',
    'DOWNLOAD_APPROVED',
    'DOWNLOAD_REJECTED',
    'DOWNLOAD_COMPLETED',
    'STATUS_CHANGED'
  ) NOT NULL,
  record_id VARCHAR(36),
  request_id VARCHAR(36),
  user_id VARCHAR(36) NOT NULL,
  user_name VARCHAR(255) NOT NULL,
  user_role ENUM('doctor', 'patient', 'admin') NOT NULL,
  actor_user_id VARCHAR(36),
  actor_user_name VARCHAR(255),
  actor_user_role ENUM('doctor', 'patient', 'admin'),
  patient_id VARCHAR(36),
  description TEXT,
  details JSON,
  blockchain_tx VARCHAR(255),
  blockchain_block_number INT,
  timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  immutable BOOLEAN DEFAULT TRUE,
  
  INDEX idx_record_id (record_id),
  INDEX idx_request_id (request_id),
  INDEX idx_user_id (user_id),
  INDEX idx_action_type (action_type),
  INDEX idx_timestamp (timestamp),
  INDEX idx_blockchain_tx (blockchain_tx),
  INDEX idx_immutable_records (immutable, timestamp),
  
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (actor_user_id) REFERENCES users(id),
  FOREIGN KEY (patient_id) REFERENCES users(id),
  FOREIGN KEY (record_id) REFERENCES medical_records(id) ON DELETE SET NULL,
  FOREIGN KEY (request_id) REFERENCES download_requests(id) ON DELETE SET NULL
);
```

### 2. Run via MySQL Client

```bash
mysql -u root -p medical_record < db/audit-migrations.sql
```

Or using MySQL Workbench/phpMyAdmin:
1. Select the `medical_record` database
2. Paste the SQL from above
3. Execute

## Features

### 1. Immutable Transaction Recording

Every action is permanently recorded:
- **RECORD_CREATED**: When a doctor creates a medical record
- **RECORD_DELETED**: When a record is deleted (transaction remains permanent)
- **DOWNLOAD_REQUESTED**: When a patient requests to download
- **DOWNLOAD_APPROVED**: When admin approves a download request
- **DOWNLOAD_REJECTED**: When admin rejects a download request
- **DOWNLOAD_COMPLETED**: When patient downloads the record
- **STATUS_CHANGED**: When any status changes

### 2. Two-User Tracking

Each transaction tracks:
- **Primary User** (`user_id`, `user_name`, `user_role`): The user who initiated or is affected
- **Actor User** (`actor_user_id`, `actor_user_name`, `actor_user_role`): The user who performed the action

Example:
- Record Creation: Patient = primary user, Doctor = actor user
- Download Approval: Patient = primary user, Admin = actor user
- Record Deletion: Record creator = primary user, Deleter = actor user

### 3. Blockchain Integration

- `blockchain_tx`: Ethereum transaction hash (from Sepolia network)
- `blockchain_block_number`: Block number on the blockchain
- `timestamp`: Exact UTC timestamp of the event
- All records are immutable and cannot be deleted

### 4. Comprehensive Audit Dashboard

Access the audit trail at: `/dashboard/admin/blockchain`

Features:
- Filter by action type, user, record, or patient
- View all transaction history
- Click on blockchain transactions to view on Etherscan
- See full transaction details including JSON data
- Even deleted records have permanent transaction history

## API Endpoints

### Get Audit Logs

```bash
GET /api/audit/logs

Query Parameters:
- action_type: Filter by action (RECORD_CREATED, etc.)
- record_id: Filter by record ID
- request_id: Filter by request ID
- user_id: Filter by user ID
- patient_id: Filter by patient ID
- start_date: Filter by start date (ISO format)
- end_date: Filter by end date (ISO format)
- trail_type: "record", "patient", or "user" for specific trails
- limit: Number of results (default: 100)
- offset: Pagination offset (default: 0)

Example:
GET /api/audit/logs?record_id=rec123&action_type=RECORD_CREATED
GET /api/audit/logs?trail_type=record&record_id=rec123
GET /api/audit/logs?trail_type=patient&patient_id=pat456
GET /api/audit/logs?trail_type=user&user_id=usr789
```

## Code Integration

### Log an Event

```typescript
import { logAuditEvent } from '@/lib/audit-log'

await logAuditEvent({
  action_type: 'RECORD_CREATED',
  record_id: 'record-123',
  user_id: 'doctor-456',
  user_name: 'Dr. Smith',
  user_role: 'doctor',
  patient_id: 'patient-789',
  description: 'Medical record uploaded',
  details: {
    file_name: 'scan.pdf',
    file_size: 1024000,
  },
  blockchain_tx: 'tx_hash_here',
})
```

### Query Audit Logs

```typescript
import { 
  getAuditLogs,
  getRecordAuditTrail,
  getPatientAuditTrail,
  getUserActivityLog
} from '@/lib/audit-log'

// Get all logs with filters
const logs = await getAuditLogs({
  action_type: 'RECORD_CREATED',
  limit: 100
})

// Get full audit trail for a record (remains even if deleted)
const recordTrail = await getRecordAuditTrail('record-123')

// Get all activity for a patient
const patientTrail = await getPatientAuditTrail('patient-456')

// Get all user activity
const userActivity = await getUserActivityLog('user-789')
```

## Verification

### Verify Blockchain Transaction

1. Go to admin blockchain page: `/dashboard/admin/blockchain`
2. Find the transaction you want to verify
3. Click on the transaction hash
4. View on Etherscan to confirm on Sepolia network

### Example Etherscan URL
```
https://sepolia.etherscan.io/tx/0x1234...abcd
```

## Important Notes

1. **Immutability**: Audit records cannot be deleted or modified
2. **Record Preservation**: Even if a medical record is deleted, its audit trail remains permanently
3. **Two-User Model**: All transactions record both the primary user and the actor
4. **Blockchain Integration**: Each event is recorded on Sepolia test network
5. **Compliance**: Provides complete audit trail for regulatory compliance

## Troubleshooting

### Table Not Found Error

```bash
# Check if table exists
SHOW TABLES LIKE 'blockchain_audit_log';

# If not found, run setup:
mysql -u root -p medical_record < db/audit-migrations.sql
```

### Foreign Key Constraint Error

Ensure the `users`, `medical_records`, and `download_requests` tables exist and have proper data.

### Missing Audit Events

Check that the API routes are updated to call `logAuditEvent()`:
- `/app/api/records/create/route.ts`
- `/app/api/records/delete/route.ts`
- `/app/api/requests/create/route.ts`
- `/app/api/requests/update-status/route.ts`

## Dashboard Navigation

From the admin dashboard:
1. Click "Blockchain" in the navigation menu
2. View the "Blockchain Activity & Audit Trail" section
3. Use filters to search specific transactions
4. Click on blockchain transaction hashes to view on Etherscan
5. Click "Transaction Details" link to see full details

---

**Last Updated**: 2026
**Feature**: Immutable Blockchain Audit Trail
**Status**: Active and Production Ready
